<?php
// ========================
// PLAYERS.PHP
// ========================

require_once 'config.php';

// ========================
// AUTHENTICATION CHECK
// ========================
if (!isLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'user';

// Admin only check (optional - remove if coaches should also access)
if ($role !== 'admin' && $role !== 'coach') {
    die("Access denied. Admin or Coach only.");
}

// ========================
// HANDLE PLAYER ACTIONS
// ========================
$message = '';
$error = '';

// Add Player
if (isset($_POST['add_player'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $role = 'player';
    $status = $_POST['status'] ?? 'active';
    
    // Validation
    if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
        $error = "All fields are required.";
    } else {
        // Check if email exists
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = :email");
        $stmt->execute([':email' => $email]);
        
        if ($stmt->rowCount() > 0) {
            $error = "Email already exists.";
        } else {
            // Hash password
            $hashed_password = hashPassword($password);
            
            // Insert player
            $stmt = $conn->prepare("
                INSERT INTO users (full_name, email, phone, password_hash, role, status, created_at, updated_at) 
                VALUES (:full_name, :email, :phone, :password, :role, :status, NOW(), NOW())
            ");
            
            $result = $stmt->execute([
                ':full_name' => $full_name,
                ':email' => $email,
                ':phone' => $phone,
                ':password' => $hashed_password,
                ':role' => $role,
                ':status' => $status
            ]);
            
            if ($result) {
                $message = "Player added successfully!";
                
                // Send welcome notification
                $welcome_msg = "Welcome to SportMS! Your account has been created. Login: $email";
                sendSMS($phone, $welcome_msg);
            } else {
                $error = "Failed to add player.";
            }
        }
    }
}

// Update Player
if (isset($_POST['update_player'])) {
    $player_id = (int)$_POST['player_id'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $status = $_POST['status'];
    
    if (empty($full_name) || empty($email) || empty($phone)) {
        $error = "Name, email, and phone are required.";
    } else {
        // Check if email exists for other users
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = :email AND user_id != :user_id");
        $stmt->execute([':email' => $email, ':user_id' => $player_id]);
        
        if ($stmt->rowCount() > 0) {
            $error = "Email already exists for another user.";
        } else {
            $sql = "UPDATE users SET full_name = :full_name, email = :email, phone = :phone, status = :status, updated_at = NOW() WHERE user_id = :user_id AND role = 'player'";
            
            $stmt = $conn->prepare($sql);
            $result = $stmt->execute([
                ':full_name' => $full_name,
                ':email' => $email,
                ':phone' => $phone,
                ':status' => $status,
                ':user_id' => $player_id
            ]);
            
            if ($result) {
                $message = "Player updated successfully!";
            } else {
                $error = "Failed to update player.";
            }
        }
    }
}

// Reset Password
if (isset($_POST['reset_password'])) {
    $player_id = (int)$_POST['player_id'];
    $new_password = $_POST['new_password'];
    
    if (strlen($new_password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        $hashed_password = hashPassword($new_password);
        
        $stmt = $conn->prepare("UPDATE users SET password_hash = :password, updated_at = NOW() WHERE user_id = :user_id AND role = 'player'");
        $result = $stmt->execute([':password' => $hashed_password, ':user_id' => $player_id]);
        
        if ($result) {
            $message = "Password reset successfully!";
            
            // Get player phone for notification
            $stmt = $conn->prepare("SELECT phone FROM users WHERE user_id = :user_id");
            $stmt->execute([':user_id' => $player_id]);
            $player = $stmt->fetch();
            
            if ($player) {
                sendSMS($player['phone'], "Your SportMS password has been reset. Please login with your new password.");
            }
        } else {
            $error = "Failed to reset password.";
        }
    }
}

// Delete Player
if (isset($_GET['delete'])) {
    $player_id = (int)$_GET['delete'];
    
    // Check if player has payments
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM payments WHERE user_id = :user_id");
    $stmt->execute([':user_id' => $player_id]);
    $payment_count = $stmt->fetch()['count'];
    
    if ($payment_count > 0) {
        $error = "Cannot delete player with existing payments. Consider deactivating instead.";
    } else {
        $stmt = $conn->prepare("DELETE FROM users WHERE user_id = :user_id AND role = 'player'");
        $result = $stmt->execute([':user_id' => $player_id]);
        
        if ($result) {
            $message = "Player deleted successfully!";
        } else {
            $error = "Failed to delete player.";
        }
    }
}

// ========================
// FETCH PLAYERS LIST
// ========================
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';

$sql = "SELECT user_id, full_name, email, phone, status, created_at, last_login FROM users WHERE role = 'player'";

$params = [];
if (!empty($search)) {
    $sql .= " AND (full_name LIKE :search OR email LIKE :search OR phone LIKE :search)";
    $params[':search'] = "%$search%";
}
if (!empty($status_filter)) {
    $sql .= " AND status = :status";
    $params[':status'] = $status_filter;
}

$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$players = $stmt->fetchAll();

// Get stats
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE role = 'player'");
$stmt->execute();
$total_players = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE role = 'player' AND status = 'active'");
$stmt->execute();
$active_players = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE role = 'player' AND status = 'inactive'");
$stmt->execute();
$inactive_players = $stmt->fetch()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Players Management | Sport Management System</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        /* Dashboard Container */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            padding: 30px 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-logo h2 {
            color: white;
            font-size: 1.5rem;
            margin-bottom: 5px;
        }

        .sidebar-logo p {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.85rem;
        }

        .nav-item {
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 10px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            text-decoration: none;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(5px);
        }

        .nav-item i {
            width: 24px;
            font-size: 1.2rem;
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            border-left: 3px solid white;
        }

        .logout-btn {
            margin-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            padding-top: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
            overflow-x: hidden;
        }

        /* Header */
        .header {
            background: white;
            border-radius: 15px;
            padding: 20px 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .header h1 {
            color: #333;
            font-size: 1.5rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            color: #666;
            font-size: 0.85rem;
            margin-bottom: 10px;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #667eea;
        }

        /* Card */
        .card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .card-header h2 {
            color: #333;
            font-size: 1.2rem;
        }

        /* Buttons */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5a67d8;
            transform: translateY(-2px);
        }

        .btn-success {
            background: #10b981;
            color: white;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
        }

        .btn-sm {
            padding: 5px 12px;
            font-size: 0.8rem;
        }

        /* Search Bar */
        .search-bar {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .search-bar input, .search-bar select {
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 0.9rem;
        }

        .search-bar input {
            flex: 1;
            min-width: 200px;
        }

        /* Table */
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0f0f0;
        }

        th {
            color: #666;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
        }

        td {
            color: #333;
        }

        /* Badges */
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .badge-active {
            background: #d1fae5;
            color: #065f46;
        }

        .badge-inactive {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 15px;
            padding: 25px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #f0f0f0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #666;
            font-size: 0.85rem;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 0.9rem;
        }

        /* Alert Messages */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* Mobile Menu */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 56px;
            height: 56px;
            background: white;
            border-radius: 50%;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            border: none;
            cursor: pointer;
            z-index: 1001;
            color: #667eea;
            font-size: 1.5rem;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .overlay.active {
                display: block;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .card-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-bar {
                flex-direction: column;
            }
            
            th, td {
                padding: 8px;
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>

<div class="dashboard-container">
    <button class="mobile-menu-btn" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>
    <div class="overlay" id="overlay"></div>

     <div class="sidebar" id="sidebar">
        <div class="sidebar-logo"><h2><i class="fas fa-futbol"></i> SportMS</h2><p>Management System</p></div>
        <nav>
            <a href="dashboard.php" class="nav-item"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
            <a href="players.php" class="nav-item"><i class="fas fa-users"></i><span>Players</span></a>
            <a href="coaches.php" class="nav-item active"><i class="fas fa-chalkboard-user"></i><span>Coaches</span></a>
            
            <a href="sessions.php" class="nav-item"><i class="fas fa-calendar-alt"></i><span>Sessions</span></a>
           
            <div class="logout-btn"><a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></div>
        </nav>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1><i class="fas fa-users"></i> Players Management</h1>
            <div class="user-info">
                <div class="user-avatar">
                    <?= strtoupper(substr($full_name, 0, 1)) ?>
                </div>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success"><?= e($message) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?= e($error) ?></div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Players</h3>
                <div class="stat-number"><?= number_format($total_players) ?></div>
            </div>
            <div class="stat-card">
                <h3>Active Players</h3>
                <div class="stat-number"><?= number_format($active_players) ?></div>
            </div>
            <div class="stat-card">
                <h3>Inactive Players</h3>
                <div class="stat-number"><?= number_format($inactive_players) ?></div>
            </div>
        </div>

        <!-- Players List -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-list"></i> All Players</h2>
                <button class="btn btn-primary" onclick="openAddModal()">
                    <i class="fas fa-plus"></i> Add New Player
                </button>
            </div>
            
            <!-- Search Bar -->
            <div class="search-bar" style="margin-bottom: 20px;">
                <form method="GET" style="display: flex; gap: 10px; flex: 1; flex-wrap: wrap;">
                    <input type="text" name="search" placeholder="Search by name, email, or phone..." value="<?= e($search) ?>">
                    <select name="status">
                        <option value="">All Status</option>
                        <option value="active" <?= $status_filter == 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $status_filter == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                    <button type="submit" class="btn btn-primary">Search</button>
                    <?php if ($search || $status_filter): ?>
                        <a href="players.php" class="btn btn-warning">Clear</a>
                    <?php endif; ?>
                </form>
            </div>
            
            <div class="table-responsive">
                <?php if (count($players) > 0): ?>
                    <table>
                        <thead>
                            <tr><th>Name</th><th>Email</th><th>Phone</th><th>Status</th><th>Joined</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($players as $player): ?>
                                <tr>
                                    <td><?= e($player['full_name']) ?></td>
                                    <td><?= e($player['email']) ?></td>
                                    <td><?= e($player['phone']) ?></td>
                                    <td>
                                        <span class="badge badge-<?= $player['status'] ?>">
                                            <?= ucfirst(e($player['status'])) ?>
                                        </span>
                                    </td>
                                    <td><?= date('M d, Y', strtotime($player['created_at'])) ?></td>
                                    <td class="action-buttons">
                                        <button class="btn btn-primary btn-sm" onclick="editPlayer(<?= $player['user_id'] ?>, '<?= addslashes($player['full_name']) ?>', '<?= addslashes($player['email']) ?>', '<?= addslashes($player['phone']) ?>', '<?= $player['status'] ?>')">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <button class="btn btn-warning btn-sm" onclick="resetPassword(<?= $player['user_id'] ?>, '<?= addslashes($player['full_name']) ?>')">
                                            <i class="fas fa-key"></i> Reset
                                        </button>
                                        <a href="?delete=<?= $player['user_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this player? This cannot be undone.')">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-users" style="font-size: 3rem; color: #ddd;"></i>
                        <p>No players found</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Add Player Modal -->
<div id="addModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-user-plus"></i> Add New Player</h3>
            <button onclick="closeAddModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
        </div>
        <form method="POST">
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="full_name" required>
            </div>
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Phone *</label>
                <input type="tel" name="phone" required>
            </div>
            <div class="form-group">
                <label>Password *</label>
                <input type="password" name="password" required minlength="6">
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <button type="submit" name="add_player" class="btn btn-primary">Add Player</button>
        </form>
    </div>
</div>

<!-- Edit Player Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-edit"></i> Edit Player</h3>
            <button onclick="closeEditModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="player_id" id="edit_player_id">
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="full_name" id="edit_full_name" required>
            </div>
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" id="edit_email" required>
            </div>
            <div class="form-group">
                <label>Phone *</label>
                <input type="tel" name="phone" id="edit_phone" required>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" id="edit_status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <button type="submit" name="update_player" class="btn btn-primary">Update Player</button>
        </form>
    </div>
</div>

<!-- Reset Password Modal -->
<div id="resetModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-key"></i> Reset Password</h3>
            <button onclick="closeResetModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="player_id" id="reset_player_id">
            <div class="form-group">
                <label>Player: <span id="reset_player_name"></span></label>
            </div>
            <div class="form-group">
                <label>New Password *</label>
                <input type="password" name="new_password" required minlength="6">
            </div>
            <button type="submit" name="reset_password" class="btn btn-warning">Reset Password</button>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('addModal').classList.add('active');
    }
    
    function closeAddModal() {
        document.getElementById('addModal').classList.remove('active');
    }
    
    function editPlayer(id, name, email, phone, status) {
        document.getElementById('edit_player_id').value = id;
        document.getElementById('edit_full_name').value = name;
        document.getElementById('edit_email').value = email;
        document.getElementById('edit_phone').value = phone;
        document.getElementById('edit_status').value = status;
        document.getElementById('editModal').classList.add('active');
    }
    
    function closeEditModal() {
        document.getElementById('editModal').classList.remove('active');
    }
    
    function resetPassword(id, name) {
        document.getElementById('reset_player_id').value = id;
        document.getElementById('reset_player_name').innerText = name;
        document.getElementById('resetModal').classList.add('active');
    }
    
    function closeResetModal() {
        document.getElementById('resetModal').classList.remove('active');
    }
    
    // Close modals on outside click
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.classList.remove('active');
        }
    }
    
    // Mobile menu
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    
    function closeMenu() {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        });
    }
    
    if (overlay) {
        overlay.addEventListener('click', closeMenu);
    }
</script>

</body>
</html>