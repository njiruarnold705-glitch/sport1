<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'user';

if ($role !== 'admin' && $role !== 'coach') {
    die("Access denied.");
}

$message = '';
$error = '';

// Add Coach
if (isset($_POST['add_coach'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $specialization = trim($_POST['specialization'] ?? '');
    $status = $_POST['status'] ?? 'active';
    
    if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = :email");
        $stmt->execute([':email' => $email]);
        
        if ($stmt->rowCount() > 0) {
            $error = "Email already exists.";
        } else {
            $hashed_password = hashPassword($password);
            
            $stmt = $conn->prepare("
                INSERT INTO users (full_name, email, phone, password_hash, role, status, created_at, updated_at) 
                VALUES (:full_name, :email, :phone, :password, 'coach', :status, NOW(), NOW())
            ");
            
            $result = $stmt->execute([
                ':full_name' => $full_name,
                ':email' => $email,
                ':phone' => $phone,
                ':password' => $hashed_password,
                ':status' => $status
            ]);
            
            if ($result) {
                $message = "Coach added successfully!";
                sendSMS($phone, "Welcome to SportMS! Your coach account has been created.");
            } else {
                $error = "Failed to add coach.";
            }
        }
    }
}

// Update Coach
if (isset($_POST['update_coach'])) {
    $coach_id = (int)$_POST['coach_id'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $status = $_POST['status'];
    
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = :email AND user_id != :user_id");
    $stmt->execute([':email' => $email, ':user_id' => $coach_id]);
    
    if ($stmt->rowCount() > 0) {
        $error = "Email already exists.";
    } else {
        $stmt = $conn->prepare("
            UPDATE users SET full_name = :full_name, email = :email, phone = :phone, status = :status, updated_at = NOW() 
            WHERE user_id = :user_id AND role = 'coach'
        ");
        
        if ($stmt->execute([':full_name' => $full_name, ':email' => $email, ':phone' => $phone, ':status' => $status, ':user_id' => $coach_id])) {
            $message = "Coach updated successfully!";
        } else {
            $error = "Failed to update coach.";
        }
    }
}

// Delete Coach
if (isset($_GET['delete'])) {
    $coach_id = (int)$_GET['delete'];
    
    $stmt = $conn->prepare("DELETE FROM users WHERE user_id = :user_id AND role = 'coach'");
    if ($stmt->execute([':user_id' => $coach_id])) {
        $message = "Coach deleted successfully!";
    } else {
        $error = "Failed to delete coach.";
    }
}

// Fetch Coaches
$search = $_GET['search'] ?? '';
$sql = "SELECT user_id, full_name, email, phone, status, created_at FROM users WHERE role = 'coach'";
if (!empty($search)) {
    $sql .= " AND (full_name LIKE :search OR email LIKE :search)";
}
$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
if (!empty($search)) {
    $stmt->execute([':search' => "%$search%"]);
} else {
    $stmt->execute();
}
$coaches = $stmt->fetchAll();

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE role = 'coach'");
$stmt->execute();
$total_coaches = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE role = 'coach' AND status = 'active'");
$stmt->execute();
$active_coaches = $stmt->fetch()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Coaches | SportMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .dashboard-container { display: flex; min-height: 100vh; }
        .sidebar { width: 280px; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-right: 1px solid rgba(255,255,255,0.2); padding: 30px 20px; position: fixed; height: 100vh; overflow-y: auto; transition: transform 0.3s ease; z-index: 1000; }
        .sidebar-logo { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.2); }
        .sidebar-logo h2 { color: white; font-size: 1.5rem; }
        .sidebar-logo p { color: rgba(255,255,255,0.7); font-size: 0.85rem; }
        .nav-item { padding: 12px 15px; margin: 5px 0; border-radius: 10px; transition: all 0.3s ease; display: flex; align-items: center; gap: 12px; color: white; text-decoration: none; }
        .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.2); transform: translateX(5px); }
        .nav-item i { width: 24px; }
        .logout-btn { margin-top: 30px; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 20px; }
        .main-content { flex: 1; margin-left: 280px; padding: 30px; overflow-x: hidden; }
        .header { background: white; border-radius: 15px; padding: 20px 25px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        .header h1 { color: #333; font-size: 1.5rem; }
        .user-avatar { width: 50px; height: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 1.2rem; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; border-radius: 15px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .stat-card h3 { color: #666; font-size: 0.85rem; margin-bottom: 10px; }
        .stat-number { font-size: 2rem; font-weight: bold; color: #667eea; }
        .card { background: white; border-radius: 15px; padding: 20px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px; }
        .card-header h2 { color: #333; font-size: 1.2rem; }
        .btn { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 0.9rem; transition: all 0.3s ease; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary { background: #667eea; color: white; }
        .btn-danger { background: #ef4444; color: white; }
        .btn-sm { padding: 5px 12px; font-size: 0.8rem; }
        .search-bar { display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; }
        .search-bar input { flex: 1; padding: 10px 15px; border: 1px solid #ddd; border-radius: 8px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #f0f0f0; }
        th { color: #666; font-weight: 600; font-size: 0.85rem; }
        .badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 500; }
        .badge-active { background: #d1fae5; color: #065f46; }
        .badge-inactive { background: #fee2e2; color: #991b1b; }
        .modal { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 2000; align-items: center; justify-content: center; }
        .modal.active { display: flex; }
        .modal-content { background: white; border-radius: 15px; padding: 25px; max-width: 500px; width: 90%; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; color: #666; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; }
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #d1fae5; color: #065f46; border-left: 4px solid #10b981; }
        .alert-error { background: #fee2e2; color: #991b1b; border-left: 4px solid #ef4444; }
        .mobile-menu-btn { display: none; position: fixed; bottom: 20px; right: 20px; width: 56px; height: 56px; background: white; border-radius: 50%; box-shadow: 0 2px 10px rgba(0,0,0,0.2); border: none; cursor: pointer; z-index: 1001; color: #667eea; font-size: 1.5rem; }
        .overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 999; }
        .empty-state { text-align: center; padding: 40px; color: #999; }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .mobile-menu-btn { display: flex; align-items: center; justify-content: center; }
            .overlay.active { display: block; }
            .stats-grid { grid-template-columns: 1fr; }
            .card-header { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <button class="mobile-menu-btn" id="menuToggle"><i class="fas fa-bars"></i></button>
    <div class="overlay" id="overlay"></div>
    
    <div class="sidebar" id="sidebar">
        <div class="sidebar-logo"><h2><i class="fas fa-futbol"></i> SportMS</h2><p>Management System</p></div>
        <nav>
            <a href="dashboard.php" class="nav-item"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
            <a href="players.php" class="nav-item"><i class="fas fa-users"></i><span>Players</span></a>
            <a href="coaches.php" class="nav-item active"><i class="fas fa-chalkboard-user"></i><span>Coaches</span></a>
            
            <a href="sessions.php" class="nav-item"><i class="fas fa-calendar-alt"></i><span>Sessions</span></a>
           
            <div class="logout-btn"><a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></div>
        </nav>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1><i class="fas fa-chalkboard-user"></i> Coaches Management</h1>
            <div class="user-avatar"><?= strtoupper(substr($full_name, 0, 1)) ?></div>
        </div>
        
        <?php if ($message): ?><div class="alert alert-success"><?= e($message) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
        
        <div class="stats-grid">
            <div class="stat-card"><h3>Total Coaches</h3><div class="stat-number"><?= $total_coaches ?></div></div>
            <div class="stat-card"><h3>Active Coaches</h3><div class="stat-number"><?= $active_coaches ?></div></div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-list"></i> All Coaches</h2>
                <button class="btn btn-primary" onclick="openAddModal()"><i class="fas fa-plus"></i> Add Coach</button>
            </div>
            
            <div class="search-bar">
                <form method="GET" style="display: flex; gap: 10px; flex: 1;">
                    <input type="text" name="search" placeholder="Search coaches..." value="<?= e($search) ?>">
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>
            
            <div class="table-responsive">
                <?php if (count($coaches) > 0): ?>
                    <table>
                        <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php foreach ($coaches as $coach): ?>
                            <tr>
                                <td><?= e($coach['full_name']) ?></td>
                                <td><?= e($coach['email']) ?></td>
                                <td><?= e($coach['phone']) ?></td>
                                <td><span class="badge badge-<?= $coach['status'] ?>"><?= ucfirst($coach['status']) ?></span></td>
                                <td><?= date('M d, Y', strtotime($coach['created_at'])) ?></td>
                                <td>
                                    <button class="btn btn-primary btn-sm" onclick="editCoach(<?= $coach['user_id'] ?>, '<?= addslashes($coach['full_name']) ?>', '<?= addslashes($coach['email']) ?>', '<?= addslashes($coach['phone']) ?>', '<?= $coach['status'] ?>')"><i class="fas fa-edit"></i> Edit</button>
                                    <a href="?delete=<?= $coach['user_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this coach?')"><i class="fas fa-trash"></i> Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state"><i class="fas fa-chalkboard-user" style="font-size: 3rem; color: #ddd;"></i><p>No coaches found</p></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div id="addModal" class="modal"><div class="modal-content"><div class="modal-header" style="display: flex; justify-content: space-between; margin-bottom: 20px;"><h3>Add Coach</h3><button onclick="closeAddModal()" style="background: none; border: none; font-size: 1.5rem;">&times;</button></div>
<form method="POST"><div class="form-group"><label>Full Name *</label><input type="text" name="full_name" required></div><div class="form-group"><label>Email *</label><input type="email" name="email" required></div><div class="form-group"><label>Phone *</label><input type="tel" name="phone" required></div><div class="form-group"><label>Password *</label><input type="password" name="password" required minlength="6"></div><div class="form-group"><label>Status</label><select name="status"><option value="active">Active</option><option value="inactive">Inactive</option></select></div><button type="submit" name="add_coach" class="btn btn-primary">Add Coach</button></form></div></div>

<div id="editModal" class="modal"><div class="modal-content"><div class="modal-header" style="display: flex; justify-content: space-between; margin-bottom: 20px;"><h3>Edit Coach</h3><button onclick="closeEditModal()" style="background: none; border: none; font-size: 1.5rem;">&times;</button></div>
<form method="POST"><input type="hidden" name="coach_id" id="edit_coach_id"><div class="form-group"><label>Full Name</label><input type="text" name="full_name" id="edit_full_name" required></div><div class="form-group"><label>Email</label><input type="email" name="email" id="edit_email" required></div><div class="form-group"><label>Phone</label><input type="tel" name="phone" id="edit_phone" required></div><div class="form-group"><label>Status</label><select name="status" id="edit_status"><option value="active">Active</option><option value="inactive">Inactive</option></select></div><button type="submit" name="update_coach" class="btn btn-primary">Update Coach</button></form></div></div>

<script>
function openAddModal() { document.getElementById('addModal').classList.add('active'); }
function closeAddModal() { document.getElementById('addModal').classList.remove('active'); }
function editCoach(id, name, email, phone, status) {
    document.getElementById('edit_coach_id').value = id;
    document.getElementById('edit_full_name').value = name;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_phone').value = phone;
    document.getElementById('edit_status').value = status;
    document.getElementById('editModal').classList.add('active');
}
function closeEditModal() { document.getElementById('editModal').classList.remove('active'); }
window.onclick = function(event) { if (event.target.classList.contains('modal')) event.target.classList.remove('active'); }
const menuToggle = document.getElementById('menuToggle'), sidebar = document.getElementById('sidebar'), overlay = document.getElementById('overlay');
if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('active'); overlay.classList.toggle('active'); };
if(overlay) overlay.onclick = () => { sidebar.classList.remove('active'); overlay.classList.remove('active'); };
</script>
</body>
</html>