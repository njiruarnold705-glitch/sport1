<?php
require_once 'config.php';
session_start();

// ========================
// AUTH CHECK
// ========================
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SESSION['role'] !== 'coach') {
    if ($_SESSION['role'] === 'admin') {
        header("Location: dashboard.php");
    } else {
        header("Location: player-dashboard.php");
    }
    exit();
}

$coach_id = $_SESSION['user_id'];

// ========================
// HANDLE SESSION CREATION
// ========================
$create_error = '';
$create_success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_session'])) {
    try {
        $title = trim($_POST['title']);
        $description = trim($_POST['description']);
        $session_date = $_POST['session_date'];
        $start_time = $_POST['start_time'];
        $end_time = $_POST['end_time'];
        $location = trim($_POST['location']);
        $max_players = !empty($_POST['max_players']) ? (int)$_POST['max_players'] : null;
        $notes = trim($_POST['notes']);
        
        // Validation
        if (empty($title) || empty($session_date) || empty($start_time) || empty($end_time)) {
            $create_error = "Please fill in all required fields.";
        } elseif (strtotime($session_date) < strtotime(date('Y-m-d'))) {
            $create_error = "Cannot create sessions in the past.";
        } else {
            $stmt = $conn->prepare("
                INSERT INTO training_sessions (
                    coach_id, 
                    title, 
                    description, 
                    session_date, 
                    start_time, 
                    end_time, 
                    location, 
                    max_players, 
                    notes, 
                    status,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', NOW())
            ");
            $stmt->execute([
                $coach_id, 
                $title, 
                $description, 
                $session_date, 
                $start_time, 
                $end_time, 
                $location, 
                $max_players, 
                $notes
            ]);
            $create_success = "Training session created successfully!";
            
            // Refresh the page to show new session
            header("Refresh:0");
        }
    } catch (Exception $e) {
        $create_error = "Error creating session: " . $e->getMessage();
    }
}

// ========================
// FETCH DATA
// ========================
try {

    // Upcoming sessions
    $stmt = $conn->prepare("
        SELECT * FROM training_sessions 
        WHERE coach_id = ? 
        AND session_date >= CURDATE() 
        AND status = 'scheduled'
        ORDER BY session_date ASC, start_time ASC
    ");
    $stmt->execute([$coach_id]);
    $upcoming_sessions = $stmt->fetchAll();

    // Recent sessions
    $stmt = $conn->prepare("
        SELECT * FROM training_sessions 
        WHERE coach_id = ? 
        AND session_date < CURDATE()
        ORDER BY session_date DESC, start_time DESC
        LIMIT 5
    ");
    $stmt->execute([$coach_id]);
    $recent_sessions = $stmt->fetchAll();

    // Total players
    $stmt = $conn->query("
        SELECT COUNT(*) FROM users 
        WHERE role = 'player' AND status = 'active'
    ");
    $total_players = $stmt->fetchColumn() ?? 0;

    // Today's attendance
    $today = date('Y-m-d');
    $stmt = $conn->prepare("
        SELECT COUNT(*) 
        FROM attendance a
        JOIN training_sessions ts ON a.session_id = ts.session_id
        WHERE ts.coach_id = ?
        AND ts.session_date = ?
        AND a.status = 'present'
    ");
    $stmt->execute([$coach_id, $today]);
    $today_attendance = $stmt->fetchColumn() ?? 0;

} catch (Exception $e) {
    die("Error loading dashboard: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Coach Dashboard</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
* {margin:0; padding:0; box-sizing:border-box;}

body {
    font-family:'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#667eea,#764ba2);
}

/* LAYOUT */
.container {
    display:flex;
    min-height:100vh;
}

/* SIDEBAR */
.sidebar {
    width:260px;
    background: rgba(0,0,0,0.3);
    backdrop-filter: blur(10px);
    padding:20px;
    color:white;
}

.sidebar h2 {margin-bottom:5px;}
.sidebar p {font-size:14px; opacity:0.7;}

.sidebar a {
    display:flex;
    align-items:center;
    gap:10px;
    padding:10px;
    margin:8px 0;
    border-radius:8px;
    text-decoration:none;
    color:white;
    transition:0.3s;
}

.sidebar a:hover,
.sidebar a.active {
    background:#06b6d4;
}

/* MAIN */
.main {
    flex:1;
    padding:25px;
}

/* HEADER */
.header {
    background:white;
    border-radius:12px;
    padding:15px 20px;
    margin-bottom:20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.avatar {
    width:45px;
    height:45px;
    border-radius:50%;
    background:#06b6d4;
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-weight:bold;
}

/* STATS GRID */
.stats {
    display:grid;
    grid-template-columns: repeat(auto-fit, minmax(200px,1fr));
    gap:20px;
    margin-bottom:20px;
}

.stat-card {
    background:white;
    border-radius:12px;
    padding:20px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

.stat-card h3 {
    font-size:14px;
    color:#555;
}

.stat-card h2 {
    color:#06b6d4;
    margin-top:10px;
}

/* CARDS */
.card {
    background:white;
    border-radius:12px;
    padding:20px;
    margin-bottom:20px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

.card h3 {
    margin-bottom:15px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

/* TABLE */
table {
    width:100%;
    border-collapse:collapse;
}

th {
    text-align:left;
    padding:10px;
    background:#f1f5f9;
    font-size:14px;
}

td {
    padding:10px;
    border-bottom:1px solid #eee;
}

tr:hover {
    background:#f9fafb;
}

/* BUTTONS */
.btn-primary {
    background:#06b6d4;
    color:white;
    border:none;
    padding:10px 20px;
    border-radius:8px;
    cursor:pointer;
    font-size:14px;
    transition:0.3s;
}

.btn-primary:hover {
    background:#0891b2;
}

/* MODAL */
.modal {
    display:none;
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:100%;
    background:rgba(0,0,0,0.5);
    z-index:1000;
    align-items:center;
    justify-content:center;
}

.modal-content {
    background:white;
    border-radius:12px;
    padding:30px;
    width:90%;
    max-width:500px;
    max-height:90vh;
    overflow-y:auto;
}

.modal-content h3 {
    margin-bottom:20px;
    color:#333;
}

.modal-content input,
.modal-content textarea,
.modal-content select {
    width:100%;
    padding:10px;
    margin-bottom:15px;
    border:1px solid #ddd;
    border-radius:8px;
    font-family:inherit;
    font-size:14px;
}

.modal-content textarea {
    min-height:80px;
    resize:vertical;
}

.modal-buttons {
    display:flex;
    gap:10px;
    justify-content:flex-end;
    margin-top:20px;
}

.modal-buttons button {
    padding:10px 20px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-size:14px;
}

.btn-save {
    background:#06b6d4;
    color:white;
}

.btn-cancel {
    background:#e5e7eb;
    color:#333;
}

.alert {
    padding:12px;
    border-radius:8px;
    margin-bottom:20px;
}

.alert-success {
    background:#d1fae5;
    color:#065f46;
    border:1px solid #10b981;
}

.alert-error {
    background:#fee2e2;
    color:#991b1b;
    border:1px solid #ef4444;
}

/* Status badges */
.status-badge {
    display:inline-block;
    padding:4px 8px;
    border-radius:12px;
    font-size:12px;
    font-weight:500;
}

.status-scheduled {
    background:#e0f2fe;
    color:#0369a1;
}

.status-completed {
    background:#dcfce7;
    color:#166534;
}

.status-cancelled {
    background:#fee2e2;
    color:#991b1b;
}

/* MOBILE */
@media(max-width:768px){
    .container {flex-direction:column;}
    .sidebar {width:100%;}
    
    .modal-content {
        width:95%;
        padding:20px;
    }
}
</style>
</head>

<body>

<div class="container">

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>⚽ Coach Panel</h2>
    <p><?= htmlspecialchars($_SESSION['full_name']) ?></p>
    <hr>

    <a href="coach-dashboard.php" class="active">
        <i class="fas fa-home"></i> Dashboard
    </a>

    <a href="coach-sessions.php">
        <i class="fas fa-calendar"></i> Training Sessions
    </a>

    <a href="coach-attendance.php">
        <i class="fas fa-check"></i> Attendance
    </a>

    <a href="coach-players.php">
        <i class="fas fa-users"></i> Players
    </a>

    <br>
    <a href="logout.php" style="background:#ef4444;">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
</div>

<!-- MAIN -->
<div class="main">

<!-- HEADER -->
<div class="header">
    <h2>Dashboard</h2>
    <div class="avatar"><?= strtoupper(substr($_SESSION['full_name'],0,1)) ?></div>
</div>

<h2 style="color:white; margin-bottom:20px;">
    Welcome Coach <?= htmlspecialchars($_SESSION['full_name']) ?> 👋
</h2>

<!-- Display messages -->
<?php if ($create_success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($create_success) ?></div>
<?php endif; ?>

<?php if ($create_error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($create_error) ?></div>
<?php endif; ?>

<!-- STATS -->
<div class="stats">

<div class="stat-card">
    <h3>Total Players</h3>
    <h2><?= $total_players ?></h2>
</div>

<div class="stat-card">
    <h3>Today's Attendance</h3>
    <h2><?= $today_attendance ?></h2>
</div>

<div class="stat-card">
    <h3>Upcoming Sessions</h3>
    <h2><?= count($upcoming_sessions) ?></h2>
</div>

</div>

<!-- UPCOMING -->
<div class="card">
<h3>
    Upcoming Training Sessions
    <button class="btn-primary" onclick="openModal()">
        <i class="fas fa-plus"></i> Create Session
    </button>
</h3>

<table>
<thead>
<tr>
<th>Title</th>
<th>Date</th>
<th>Time</th>
<th>Location</th>
<th>Max Players</th>
<th>Status</th>
</tr>
</thead>
<tbody>

<?php if (count($upcoming_sessions) > 0): ?>
<?php foreach ($upcoming_sessions as $s): ?>
<tr>
<td>
    <strong><?= htmlspecialchars($s['title']) ?></strong>
    <?php if (!empty($s['description'])): ?>
        <br><small style="color:#666;"><?= htmlspecialchars(substr($s['description'], 0, 50)) . (strlen($s['description']) > 50 ? '...' : '') ?></small>
    <?php endif; ?>
</td>
<td><?= date('M d, Y', strtotime($s['session_date'])) ?></td>
<td><?= date('h:i A', strtotime($s['start_time'])) ?> - <?= date('h:i A', strtotime($s['end_time'])) ?></td>
<td><?= htmlspecialchars($s['location'] ?: '—') ?></td>
<td><?= $s['max_players'] ?: 'Unlimited' ?></td>
<td><span class="status-badge status-<?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span></td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr>
<td colspan="6" style="text-align:center;">No upcoming sessions</td>
</tr>
<?php endif; ?>

</tbody>
</table>
</div>

<!-- RECENT -->
<div class="card">
<h3>Recent Sessions</h3>

<table>
<thead>
<tr>
<th>Title</th>
<th>Date</th>
<th>Time</th>
<th>Status</th>
</tr>
</thead>
<tbody>

<?php if (count($recent_sessions) > 0): ?>
<?php foreach ($recent_sessions as $s): ?>
<tr>
<td><?= htmlspecialchars($s['title']) ?></td>
<td><?= date('M d, Y', strtotime($s['session_date'])) ?></td>
<td><?= date('h:i A', strtotime($s['start_time'])) ?></td>
<td><span class="status-badge status-<?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span></td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr>
<td colspan="4" style="text-align:center;">No past sessions</td>
</tr>
<?php endif; ?>

</tbody>
</table>
</div>

</div>
</div>

<!-- CREATE SESSION MODAL -->
<div id="sessionModal" class="modal">
    <div class="modal-content">
        <h3>Create New Training Session</h3>
        
        <form method="POST" action="">
            <input type="text" name="title" placeholder="Session Title *" required>
            
            <textarea name="description" placeholder="Session Description (optional)"></textarea>
            
            <label style="font-size:12px; color:#666; margin-bottom:5px; display:block;">Session Date *</label>
            <input type="date" name="session_date" required min="<?= date('Y-m-d') ?>">
            
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                <div>
                    <label style="font-size:12px; color:#666; margin-bottom:5px; display:block;">Start Time *</label>
                    <input type="time" name="start_time" required>
                </div>
                <div>
                    <label style="font-size:12px; color:#666; margin-bottom:5px; display:block;">End Time *</label>
                    <input type="time" name="end_time" required>
                </div>
            </div>
            
            <input type="text" name="location" placeholder="Location (optional)">
            
            <input type="number" name="max_players" placeholder="Max Players (optional)" min="1">
            
            <textarea name="notes" placeholder="Additional Notes (optional)" rows="3"></textarea>
            
            <div class="modal-buttons">
                <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                <button type="submit" name="create_session" class="btn-save">Create Session</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('sessionModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('sessionModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    let modal = document.getElementById('sessionModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

// Validate that end time is after start time
document.querySelector('form').addEventListener('submit', function(e) {
    let startTime = document.querySelector('input[name="start_time"]').value;
    let endTime = document.querySelector('input[name="end_time"]').value;
    
    if (startTime && endTime && startTime >= endTime) {
        e.preventDefault();
        alert('End time must be after start time');
    }
});
</script>

</body>
</html>