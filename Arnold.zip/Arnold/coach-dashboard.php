<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) redirect('login.php');

if ($_SESSION['role'] !== 'coach') {
    if ($_SESSION['role'] === 'admin') redirect('dashboard.php');
    else redirect('player-dashboard.php');
}

$coach_id = $_SESSION['user_id'];

try {

    $stmt = $conn->prepare("
        SELECT * FROM training_sessions 
        WHERE coach_id = ? 
        AND session_date >= CURDATE() 
        AND status = 'scheduled' 
        ORDER BY session_date ASC
    ");
    $stmt->execute([$coach_id]);
    $upcoming_sessions = $stmt->fetchAll();

    $stmt = $conn->prepare("
        SELECT * FROM training_sessions 
        WHERE coach_id = ? 
        AND session_date < CURDATE() 
        ORDER BY session_date DESC 
        LIMIT 5
    ");
    $stmt->execute([$coach_id]);
    $recent_sessions = $stmt->fetchAll();

    $total_players = $conn->query("
        SELECT COUNT(*) FROM users 
        WHERE role='player' AND status='active'
    ")->fetchColumn();

    $today = date('Y-m-d');
    $stmt = $conn->prepare("
        SELECT COUNT(*) 
        FROM attendance a
        JOIN training_sessions ts ON a.session_id = ts.session_id
        WHERE ts.coach_id=? AND ts.session_date=? AND a.status='present'
    ");
    $stmt->execute([$coach_id, $today]);
    $today_attendance = $stmt->fetchColumn();

} catch (Exception $e) {
    die("Error loading dashboard");
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Coach Dashboard</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
* {margin:0; padding:0; box-sizing:border-box;}

body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#667eea,#764ba2);
}

/* LAYOUT */
.container {
    display:flex;
    min-height:100vh;
}

/* SIDEBAR */
.sidebar {
    width:260px;
    background: rgba(0,0,0,0.3);
    backdrop-filter: blur(10px);
    padding:20px;
    color:white;
}

.sidebar h2 {margin-bottom:5px;}
.sidebar p {font-size:14px; opacity:0.7;}

.sidebar a {
    display:flex;
    align-items:center;
    gap:10px;
    padding:10px;
    margin:8px 0;
    border-radius:8px;
    color:white;
    text-decoration:none;
    transition:0.3s;
}

.sidebar a:hover,
.sidebar a.active {
    background:#06b6d4;
}

/* MAIN */
.main {
    flex:1;
    padding:25px;
}

/* HEADER */
.header {
    background:white;
    padding:15px 20px;
    border-radius:12px;
    margin-bottom:20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.avatar {
    width:45px;
    height:45px;
    border-radius:50%;
    background:#06b6d4;
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-weight:bold;
}

/* GRID STATS */
.stats {
    display:grid;
    grid-template-columns: repeat(auto-fit, minmax(200px,1fr));
    gap:20px;
    margin-bottom:20px;
}

.stat-card {
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

.stat-card h3 {
    font-size:14px;
    color:#555;
}

.stat-card h2 {
    color:#06b6d4;
    margin-top:10px;
}

/* CARDS */
.card {
    background:white;
    padding:20px;
    border-radius:12px;
    margin-bottom:20px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

/* TABLE */
table {
    width:100%;
    border-collapse:collapse;
}

th {
    text-align:left;
    padding:10px;
    background:#f1f5f9;
}

td {
    padding:10px;
    border-bottom:1px solid #eee;
}

tr:hover {
    background:#f9fafb;
}

/* RESPONSIVE */
@media(max-width:768px){
    .container {flex-direction:column;}
    .sidebar {width:100%;}
}
</style>
</head>

<body>

<div class="container">

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>⚽ Coach Panel</h2>
    <p><?= htmlspecialchars($_SESSION['full_name']) ?></p>
    <hr>

    <a href="coach-dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a>
    <a href="coach-sessions.php"><i class="fas fa-calendar"></i> Sessions</a>
    <a href="coach-attendance.php"><i class="fas fa-check"></i> Attendance</a>
    <a href="coach-players.php"><i class="fas fa-users"></i> Players</a>

    <br>
    <a href="logout.php" style="background:#ef4444;"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="header">
    <h2>Dashboard</h2>
    <div class="avatar"><?= strtoupper(substr($_SESSION['full_name'],0,1)) ?></div>
</div>

<h2 style="color:white; margin-bottom:20px;">
    Welcome Coach <?= htmlspecialchars($_SESSION['full_name']) ?> 👋
</h2>

<!-- STATS -->
<div class="stats">

<div class="stat-card">
    <h3>Total Players</h3>
    <h2><?= $total_players ?></h2>
</div>

<div class="stat-card">
    <h3>Today's Attendance</h3>
    <h2><?= $today_attendance ?></h2>
</div>

<div class="stat-card">
    <h3>Upcoming Sessions</h3>
    <h2><?= count($upcoming_sessions) ?></h2>
</div>

</div>

<!-- UPCOMING -->
<div class="card">
<h3>Upcoming Training Sessions</h3>

<table>
<tr><th>Title</th><th>Date</th><th>Time</th><th>Location</th></tr>

<?php if ($upcoming_sessions): ?>
<?php foreach ($upcoming_sessions as $s): ?>
<tr>
<td><?= htmlspecialchars($s['title']) ?></td>
<td><?= date('M d, Y', strtotime($s['session_date'])) ?></td>
<td><?= date('h:i A', strtotime($s['start_time'])) ?></td>
<td><?= htmlspecialchars($s['location']) ?></td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr><td colspan="4">No upcoming sessions</td></tr>
<?php endif; ?>

</table>
</div>

<!-- RECENT -->
<div class="card">
<h3>Recent Sessions</h3>

<table>
<tr><th>Title</th><th>Date</th></tr>

<?php if ($recent_sessions): ?>
<?php foreach ($recent_sessions as $s): ?>
<tr>
<td><?= htmlspecialchars($s['title']) ?></td>
<td><?= date('M d, Y', strtotime($s['session_date'])) ?></td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr><td colspan="2">No recent sessions</td></tr>
<?php endif; ?>

</table>
</div>

</div>
</div>

</body>
</html>