<?php
require_once 'config.php';

// DEBUG MODE (REMOVE IN PRODUCTION)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Redirect if logged in
if (isLoggedIn()) {
    $role = getUserRole($_SESSION['user_id']);
    if ($role === 'admin') redirect('dashboard.php');
    elseif ($role === 'coach') redirect('coach-dashboard.php');
    else redirect('player-dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    header('Content-Type: application/json');

    $role = $_POST['role'] ?? 'player';
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // VALIDATION
    if (!$full_name || !$email || !$phone || !$password) {
        echo json_encode(['success' => false, 'message' => 'All fields required']); exit;
    }

    if ($password !== $confirm_password) {
        echo json_encode(['success' => false, 'message' => 'Passwords do not match']); exit;
    }

    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password too short']); exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email']); exit;
    }

    // CHECK EMAIL
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Email already exists']); exit;
    }

    try {
        $conn->beginTransaction();

        // HASH PASSWORD
        $hashed_password = hashPassword($password);

        // INSERT USER
        $stmt = $conn->prepare("
            INSERT INTO users 
            (full_name, email, phone, password_hash, role, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 'active', NOW(), NOW())
        ");

        $stmt->execute([$full_name, $email, $phone, $hashed_password, $role]);

        $user_id = $conn->lastInsertId();

        // ========================
        // TRY PLAYER INSERT (SAFE)
        // ========================
        if ($role === 'player') {
            try {
                $stmt = $conn->prepare("INSERT INTO players (user_id) VALUES (?)");
                $stmt->execute([$user_id]);
            } catch (Exception $e) {
                // Ignore if table structure differs
            }
        }

        // ========================
        // PAYMENT (SAFE)
        // ========================
        try {
            $payment_type = $_POST['payment_type'] ?? 'membership';

            $fee_amount = match($payment_type) {
                'membership' => 500,
                'registration' => 300,
                'both' => 800,
                default => 0
            };

            $transaction_code = 'SIM-' . date('Ymd') . '-' . $user_id;

            recordPayment($user_id, $fee_amount, $payment_type, 'simulated', $transaction_code);
        } catch (Exception $e) {
            // Ignore payment errors
        }

        // ========================
        // NOTIFICATIONS (SAFE)
        // ========================
        try {
            sendSMS($phone, "Welcome $full_name!");
            sendWhatsApp($phone, "Welcome $full_name!");
        } catch (Exception $e) {}

        $conn->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Registration successful!',
            'redirect' => 'login.php'
        ]);
        exit;

    } catch (Exception $e) {
        $conn->rollBack();

        // SHOW REAL ERROR
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Register | Sport Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
        }

        /* Background Pattern */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="80" cy="40" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="80" r="2" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
            opacity: 0.3;
            pointer-events: none;
        }

        /* Main Container */
        .register-container {
            width: 100%;
            max-width: 480px;
            position: relative;
            z-index: 1;
            animation: slideUp 0.5s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Card */
        .register-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            padding: 40px 32px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease;
        }

        .register-card:hover {
            transform: translateY(-5px);
        }

        /* Header */
        .register-header {
            text-align: center;
            margin-bottom: 32px;
        }

        .register-header .icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }

        .register-header .icon i {
            font-size: 32px;
            color: white;
        }

        .register-header h2 {
            color: #333;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .register-header p {
            color: #666;
            font-size: 14px;
        }

        /* Form */
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-size: 13px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-group label i {
            margin-right: 8px;
            color: #667eea;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: white;
            font-family: inherit;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-group input:hover,
        .form-group select:hover {
            border-color: #667eea;
        }

        /* Price Badge */
        .price-badge {
            position: absolute;
            right: 12px;
            top: 38px;
            background: #f0f0f0;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            color: #667eea;
            font-weight: 600;
            pointer-events: none;
        }

        /* Button */
        .register-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 24px;
        }

        .register-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .register-btn:active {
            transform: translateY(0);
        }

        /* Login Link */
        .login-link {
            text-align: center;
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
        }

        .login-link p {
            color: #666;
            font-size: 14px;
        }

        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .login-link a:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        /* Message Alert */
        .alert {
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: #d1fae5;
            border-left: 4px solid #10b981;
            color: #065f46;
        }

        .alert-error {
            background: #fee2e2;
            border-left: 4px solid #ef4444;
            color: #991b1b;
        }

        .alert i {
            font-size: 18px;
        }

        /* Role Toggle */
        .role-toggle {
            display: flex;
            gap: 12px;
            margin-bottom: 20px;
        }

        .role-option {
            flex: 1;
            position: relative;
        }

        .role-option input {
            position: absolute;
            opacity: 0;
            cursor: pointer;
        }

        .role-label {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px;
            background: #f5f5f5;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .role-option input:checked + .role-label {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-color: #667eea;
            color: white;
        }

        .role-label i {
            font-size: 18px;
        }

        /* Responsive */
        @media (max-width: 480px) {
            .register-card {
                padding: 32px 24px;
            }
            
            .register-header h2 {
                font-size: 24px;
            }
            
            .form-group input,
            .form-group select {
                padding: 12px 14px;
                font-size: 14px;
            }
            
            .role-label {
                padding: 10px;
                font-size: 14px;
            }
        }

        /* Loading State */
        .register-btn.loading {
            opacity: 0.7;
            cursor: not-allowed;
        }

        .register-btn.loading i {
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</head>

<body>

<div class="register-container">
    <div class="register-card">
        <div class="register-header">
            <div class="icon">
                <i class="fas fa-futbol"></i>
            </div>
            <h2>Create Account</h2>
            <p>Join SportMS and start your journey</p>
        </div>

        <div id="msg"></div>

        <form id="form">
            <!-- Role Selection -->
            <div class="role-toggle">
                <div class="role-option">
                    <input type="radio" name="role" value="player" id="role_player" checked>
                    <label for="role_player" class="role-label">
                        <i class="fas fa-users"></i>
                        <span>Player</span>
                    </label>
                </div>
                <div class="role-option">
                    <input type="radio" name="role" value="coach" id="role_coach">
                    <label for="role_coach" class="role-label">
                        <i class="fas fa-chalkboard-user"></i>
                        <span>Coach</span>
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label><i class="fas fa-user"></i> Full Name</label>
                <input type="text" name="full_name" placeholder="Enter your full name" required>
            </div>

            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email Address</label>
                <input type="email" name="email" placeholder="you@example.com" required>
            </div>

            <div class="form-group">
                <label><i class="fas fa-phone"></i> Phone Number</label>
                <input type="tel" name="phone" placeholder="+254700000000" required>
            </div>

            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" placeholder="Min. 6 characters" required>
            </div>

            <div class="form-group">
                <label><i class="fas fa-check-circle"></i> Confirm Password</label>
                <input type="password" name="confirm_password" placeholder="Re-enter password" required>
            </div>

            <div class="form-group">
                <label><i class="fas fa-credit-card"></i> Payment Package</label>
                <select name="payment_type">
                    <option value="membership">🏆 Membership - KES 500</option>
                    <option value="registration">📝 Registration - KES 300</option>
                    <option value="both">⭐ Both - KES 800 (Save KES 0)</option>
                </select>
            </div>

            <button type="submit" class="register-btn">
                <i class="fas fa-user-plus"></i>
                <span>Create Account</span>
            </button>
        </form>

        <div class="login-link">
            <p>Already have an account? <a href="login.php">Sign In</a></p>
        </div>
    </div>
</div>

<script>
document.getElementById('form').addEventListener('submit', function(e){
    e.preventDefault();

    let formData = new FormData(this);
    let submitBtn = document.querySelector('.register-btn');
    let originalText = submitBtn.innerHTML;
    
    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner"></i> Creating Account...';
    submitBtn.classList.add('loading');
    submitBtn.disabled = true;

    fetch('', { method:'POST', body:formData })
    .then(res => res.json())
    .then(data => {
        let msgDiv = document.getElementById('msg');

        if (data.success) {
            msgDiv.innerHTML = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span>${data.message}</span>
                </div>
            `;
            
            // Clear form
            document.getElementById('form').reset();
            
            setTimeout(() => {
                window.location.href = data.redirect;
            }, 1500);
        } else {
            msgDiv.innerHTML = `
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>${data.message}</span>
                </div>
            `;
            
            // Reset button
            submitBtn.innerHTML = originalText;
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
            
            // Auto-hide error after 5 seconds
            setTimeout(() => {
                if (msgDiv.firstChild) {
                    msgDiv.innerHTML = '';
                }
            }, 5000);
        }
    })
    .catch(error => {
        let msgDiv = document.getElementById('msg');
        msgDiv.innerHTML = `
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span>Network error. Please try again.</span>
            </div>
        `;
        
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;
    });
});
</script>

</body>
</html>