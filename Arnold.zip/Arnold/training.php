<?php
require_once 'config.php';

if (!isLoggedIn()) redirect('login.php');

// Fetch sessions
$stmt = $conn->query("
    SELECT ts.*, u.full_name as coach_name 
    FROM training_sessions ts
    JOIN users u ON ts.coach_id = u.user_id
    ORDER BY ts.session_date DESC
");
$sessions = $stmt->fetchAll();

$full_name = $_SESSION['full_name'];
$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Training Sessions</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #667eea, #764ba2);
    min-height: 100vh;
    padding: 20px;
}

/* CONTAINER */
.container {
    max-width: 1000px;
    margin: auto;
}

/* HEADER */
.header {
    text-align: center;
    margin-bottom: 30px;
    color: white;
}

.avatar {
    width: 100px;
    height: 100px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: auto;
}

.avatar i {
    font-size: 45px;
    color: #667eea;
}

.header h2 {
    margin-top: 10px;
}

/* CARD */
.card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

/* TITLE */
.card-title {
    font-size: 20px;
    margin-bottom: 20px;
    color: #333;
}

/* TABLE */
.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #f1f5f9;
    text-align: left;
    padding: 12px;
    font-size: 14px;
}

td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}

tr:hover {
    background: #f9fafb;
}

/* BADGES */
.badge {
    background: #e0e7ff;
    color: #4338ca;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
}

/* EMPTY */
.empty {
    text-align: center;
    padding: 20px;
    color: gray;
}

/* BUTTON */
.back-btn {
    display: inline-block;
    margin-top: 20px;
    text-decoration: none;
    color: white;
    font-weight: bold;
}

/* RESPONSIVE */
@media(max-width:600px){
    .avatar {
        width: 80px;
        height: 80px;
    }
}
</style>

</head>
<body>

<div class="container">

    <!-- HEADER -->
    <div class="header">
        <div class="avatar">
            <i class="fas fa-futbol"></i>
        </div>
        <h2>Training Sessions</h2>
        <p><?= htmlspecialchars($full_name) ?> (<?= ucfirst($role) ?>)</p>
    </div>

    <!-- CARD -->
    <div class="card">

        <div class="card-title">
            <i class="fas fa-calendar-alt"></i> Upcoming & Past Sessions
        </div>

        <div class="table-wrapper">
            <table>
                <tr>
                    <th>Title</th>
                    <th>Coach</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Location</th>
                </tr>

                <?php if ($sessions): ?>
                    <?php foreach ($sessions as $s): ?>
                    <tr>
                        <td><?= htmlspecialchars($s['title']) ?></td>
                        <td><?= htmlspecialchars($s['coach_name']) ?></td>
                        <td>
                            <span class="badge">
                                <?= date('M d, Y', strtotime($s['session_date'])) ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars($s['start_time']) ?></td>
                        <td><?= htmlspecialchars($s['location']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="empty">
                            <i class="fas fa-calendar-times"></i><br><br>
                            No training sessions available
                        </td>
                    </tr>
                <?php endif; ?>

            </table>
        </div>

    </div>

    <!-- BACK -->
    <div style="text-align:center;">
        <a href="player-dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>

</div>

</body>
</html>