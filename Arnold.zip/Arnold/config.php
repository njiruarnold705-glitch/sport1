<?php
// =====================================================
// SECURE DATABASE CONFIGURATION FILE
// Sport Management System (Improved Version)
// =====================================================

// ========================
// DATABASE CONFIG
// ========================
define('DB_HOST', 'localhost');
define('DB_NAME', 'cnxkgcvx_Arnold');
define('DB_USER', 'cnxkgcvx_Arnold');
define('DB_PASS', 'Project2026#'); // <-- updated password

// ========================
// CREATE PDO CONNECTION
// ========================
try {
    $conn = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // throw errors
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false // real prepared statements
        ]
    );
} catch (PDOException $e) {
    error_log($e->getMessage()); // log error
    die("Database connection failed."); // safe message
}

// ========================
// SESSION START (SECURE)
// ========================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
    session_regenerate_id(true);
}

// ========================
// HELPER FUNCTIONS
// ========================

// Escape output (for HTML)
function e($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

// ========================
// AUTH FUNCTIONS
// ========================

// Hash password
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Verify password
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Check login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Redirect
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// ========================
// MESSAGE HELPERS
// ========================
function showSuccess($message) {
    return '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . e($message) . '</div>';
}

function showError($message) {
    return '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> ' . e($message) . '</div>';
}

// ========================
// NOTIFICATION SYSTEM
// ========================

// Send SMS (log only)
function sendSMS($phone, $message) {
    global $conn;

    $sql = "INSERT INTO notifications (user_id, type, recipient_phone, message, status) 
            VALUES (:user_id, :type, :phone, :message, :status)";

    $stmt = $conn->prepare($sql);

    return $stmt->execute([
        ':user_id' => 0,
        ':type' => 'sms',
        ':phone' => $phone,
        ':message' => $message,
        ':status' => 'sent'
    ]);
}

// Send WhatsApp (log only)
function sendWhatsApp($phone, $message) {
    global $conn;

    $sql = "INSERT INTO notifications (user_id, type, recipient_phone, message, status) 
            VALUES (:user_id, :type, :phone, :message, :status)";

    $stmt = $conn->prepare($sql);

    return $stmt->execute([
        ':user_id' => 0,
        ':type' => 'whatsapp',
        ':phone' => $phone,
        ':message' => $message,
        ':status' => 'sent'
    ]);
}

// ========================
// PAYMENT SYSTEM
// ========================
function recordPayment($user_id, $amount, $payment_type, $payment_method, $transaction_code = null) {
    global $conn;

    $sql = "INSERT INTO payments 
        (user_id, amount, payment_type, payment_method, transaction_code, status, notified_sms) 
        VALUES (:user_id, :amount, :payment_type, :payment_method, :transaction_code, 'completed', 1)";

    $stmt = $conn->prepare($sql);

    $success = $stmt->execute([
        ':user_id' => (int)$user_id,
        ':amount' => (float)$amount,
        ':payment_type' => $payment_type,
        ':payment_method' => $payment_method,
        ':transaction_code' => $transaction_code
    ]);

    if ($success) {
        return $conn->lastInsertId();
    }

    return false;
}
?>