<?php
require_once 'config.php';
session_start();

// ========================
// AUTH CHECK
// ========================
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SESSION['role'] !== 'coach') {
    if ($_SESSION['role'] === 'admin') {
        header("Location: dashboard.php");
    } else {
        header("Location: player-dashboard.php");
    }
    exit();
}

$coach_id = $_SESSION['user_id'];
$user_id = $_SESSION['user_id'];
$message = "";
$error_message = "";

// ========================
// FETCH SESSIONS
// ========================
$stmt = $conn->prepare("
    SELECT * FROM training_sessions 
    WHERE coach_id = ? 
    ORDER BY session_date DESC, start_time DESC
");
$stmt->execute([$coach_id]);
$sessions = $stmt->fetchAll();

// ========================
// FETCH PLAYERS WITH THEIR DETAILS
// ========================
$stmt = $conn->prepare("
    SELECT p.player_id, u.user_id, u.full_name, u.email
    FROM players p
    JOIN users u ON p.user_id = u.user_id
    WHERE u.status = 'active'
    ORDER BY u.full_name ASC
");
$stmt->execute();
$players = $stmt->fetchAll();

// ========================
// GET SELECTED SESSION (for pre-loading attendance data)
// ========================
$selected_session_id = isset($_POST['session_id']) ? $_POST['session_id'] : (isset($_GET['session_id']) ? $_GET['session_id'] : '');
$existing_attendance = [];

if (!empty($selected_session_id)) {
    $stmt = $conn->prepare("
        SELECT * FROM attendance 
        WHERE session_id = ?
    ");
    $stmt->execute([$selected_session_id]);
    $attendance_records = $stmt->fetchAll();
    
    // Create an associative array for easy lookup
    foreach ($attendance_records as $record) {
        $existing_attendance[$record['player_id']] = $record;
    }
}

// ========================
// SAVE ATTENDANCE
// ========================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {

    $session_id = $_POST['session_id'] ?? '';

    if (empty($session_id)) {
        $error_message = "Please select a session.";
    } else {
        try {
            $conn->beginTransaction();
            
            foreach ($players as $player) {
                $player_id = $player['player_id'];
                $status = $_POST['status'][$player_id] ?? 'absent';
                $remarks = $_POST['remarks'][$player_id] ?? null;
                $check_in_time = null;
                
                // If status is present and check-in time is provided
                if ($status === 'present' && isset($_POST['check_in_time'][$player_id]) && !empty($_POST['check_in_time'][$player_id])) {
                    $check_in_time = $_POST['check_in_time'][$player_id];
                } elseif ($status === 'present') {
                    // Auto-set check-in time to current time if not provided
                    $check_in_time = date('H:i:s');
                }
                
                // Check existing record
                $check = $conn->prepare("
                    SELECT attendance_id 
                    FROM attendance 
                    WHERE session_id = ? AND player_id = ?
                ");
                $check->execute([$session_id, $player_id]);
                
                if ($check->rowCount() == 0) {
                    // Insert new record
                    $stmt = $conn->prepare("
                        INSERT INTO attendance (
                            session_id, 
                            player_id, 
                            status, 
                            check_in_time, 
                            remarks, 
                            marked_by, 
                            marked_at
                        )
                        VALUES (?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $stmt->execute([
                        $session_id, 
                        $player_id, 
                        $status, 
                        $check_in_time, 
                        $remarks, 
                        $user_id
                    ]);
                } else {
                    // Update existing record
                    $stmt = $conn->prepare("
                        UPDATE attendance 
                        SET status = ?, 
                            check_in_time = ?, 
                            remarks = ?, 
                            marked_by = ?, 
                            marked_at = NOW()
                        WHERE session_id = ? AND player_id = ?
                    ");
                    $stmt->execute([
                        $status, 
                        $check_in_time, 
                        $remarks, 
                        $user_id,
                        $session_id, 
                        $player_id
                    ]);
                }
            }
            
            $conn->commit();
            $message = "Attendance saved successfully!";
            
            // Refresh the page to show updated data
            header("Location: coach-attendance.php?session_id=" . $session_id . "&success=1");
            exit();
            
        } catch (Exception $e) {
            $conn->rollBack();
            $error_message = "Error saving attendance: " . $e->getMessage();
        }
    }
}

// Check for success message from redirect
if (isset($_GET['success'])) {
    $message = "Attendance saved successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Coach Attendance</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
* {margin:0; padding:0; box-sizing:border-box;}

body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#667eea,#764ba2);
    color:white;
}

/* SIDEBAR */
.sidebar {
    width:260px;
    height:100vh;
    position:fixed;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    padding:25px;
}

.sidebar h2 {margin-bottom:5px;}
.sidebar p {font-size:14px; color:#ddd; margin-bottom:15px;}

.sidebar a {
    display:block;
    padding:12px;
    margin:6px 0;
    border-radius:10px;
    color:white;
    text-decoration:none;
    transition:0.3s;
}

.sidebar a:hover,
.sidebar a.active {
    background: rgba(255,255,255,0.2);
}

/* MAIN */
.main {
    margin-left:280px;
    padding:30px;
}

/* CARD */
.card {
    background:white;
    color:#1e293b;
    border-radius:15px;
    padding:20px;
    margin-bottom:20px;
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
}

/* HEADER */
.header {
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

/* FORM */
select, button, input[type="time"], textarea {
    padding:10px;
    border-radius:8px;
    border:1px solid #ddd;
    width:100%;
    margin-top:5px;
    font-family: inherit;
}

textarea {
    resize: vertical;
    min-height: 60px;
}

button {
    background:#667eea;
    color:white;
    border:none;
    cursor:pointer;
    transition:0.3s;
    font-weight:bold;
}

button:hover {
    background:#5a67d8;
}

/* TABLE */
.table-container {
    overflow-x: auto;
}

table {
    width:100%;
    border-collapse:collapse;
    margin-top:15px;
}

th {
    background:#f1f5f9;
    text-align:left;
    padding:12px;
    font-size:14px;
}

td {
    padding:12px;
    border-bottom:1px solid #eee;
}

tr:hover {
    background:#f9fafb;
}

/* ALERT */
.alert {
    padding:15px;
    border-radius:10px;
    margin-bottom:15px;
}

.success {
    background:#d1fae5; 
    color:#065f46;
    border-left:4px solid #10b981;
}

.error {
    background:#fee2e2; 
    color:#991b1b;
    border-left:4px solid #ef4444;
}

/* STATUS BADGES */
.status-badge {
    display:inline-block;
    padding:4px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:bold;
}

.status-present {
    background:#d1fae5;
    color:#065f46;
}

.status-absent {
    background:#fee2e2;
    color:#991b1b;
}

.status-late {
    background:#fed7aa;
    color:#92400e;
}

/* SESSION INFO */
.session-info {
    background:#f8fafc;
    padding:15px;
    border-radius:10px;
    margin-bottom:20px;
}

.session-info h4 {
    color:#1e293b;
    margin-bottom:5px;
}

.session-info p {
    color:#475569;
    font-size:14px;
}

/* FORM GROUP */
.form-group {
    margin-bottom:15px;
}

label {
    display:block;
    font-size:14px;
    font-weight:500;
    color:#334155;
    margin-bottom:5px;
}

/* BUTTONS */
.btn-primary {
    background:#667eea;
    color:white;
    padding:12px 24px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-weight:bold;
    margin-top:20px;
}

.btn-primary:hover {
    background:#5a67d8;
}

/* RESPONSIVE */
@media(max-width:768px){
    .sidebar {
        position:relative; 
        width:100%; 
        height:auto;
    }
    .main {
        margin-left:0;
    }
    
    th, td {
        padding:8px;
        font-size:12px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2><i class="fas fa-user"></i> Coach Panel</h2>
    <p><?= htmlspecialchars($_SESSION['full_name']) ?></p>
    <hr>

    <a href="coach-dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="coach-sessions.php"><i class="fas fa-calendar"></i> Sessions</a>
    <a href="coach-attendance.php" class="active"><i class="fas fa-check"></i> Attendance</a>
    <a href="coach-players.php"><i class="fas fa-users"></i> Players</a>

    <br>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="header">
    <h1><i class="fas fa-check-circle"></i> Mark Attendance</h1>
</div>

<!-- MESSAGE -->
<?php if ($message): ?>
<div class="alert success">
    <i class="fas fa-check-circle"></i> <?= htmlspecialchars($message) ?>
</div>
<?php endif; ?>

<?php if ($error_message): ?>
<div class="alert error">
    <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error_message) ?>
</div>
<?php endif; ?>

<!-- ATTENDANCE FORM -->
<div class="card">

<form method="POST" id="attendanceForm">

<div class="form-group">
    <label for="session_id"><i class="fas fa-calendar-alt"></i> Select Training Session</label>
    <select name="session_id" id="session_id" required onchange="this.form.submit()">
        <option value="">-- Select Session --</option>
        <?php foreach ($sessions as $s): ?>
            <option value="<?= $s['session_id'] ?>" <?= $selected_session_id == $s['session_id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($s['title']) ?> (<?= date('M d, Y', strtotime($s['session_date'])) ?> - <?= date('h:i A', strtotime($s['start_time'])) ?>)
            </option>
        <?php endforeach; ?>
    </select>
</div>

<?php if (!empty($selected_session_id)): 
    // Get session details
    $session_details = null;
    foreach ($sessions as $s) {
        if ($s['session_id'] == $selected_session_id) {
            $session_details = $s;
            break;
        }
    }
?>

<div class="session-info">
    <h4><i class="fas fa-info-circle"></i> Session Details</h4>
    <p><strong>Title:</strong> <?= htmlspecialchars($session_details['title']) ?></p>
    <p><strong>Date:</strong> <?= date('l, F d, Y', strtotime($session_details['session_date'])) ?></p>
    <p><strong>Time:</strong> <?= date('h:i A', strtotime($session_details['start_time'])) ?> - <?= date('h:i A', strtotime($session_details['end_time'])) ?></p>
    <p><strong>Location:</strong> <?= htmlspecialchars($session_details['location'] ?: 'Not specified') ?></p>
</div>

<h3 style="margin-top:20px; margin-bottom:15px;">
    <i class="fas fa-users"></i> Players Attendance
</h3>

<div class="table-container">
<table>
    <thead>
        <tr>
            <th>Player Name</th>
            <th>Status</th>
            <th>Check-in Time</th>
            <th>Remarks</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($players as $p): 
            $attendance = isset($existing_attendance[$p['player_id']]) ? $existing_attendance[$p['player_id']] : null;
            $status = $attendance ? $attendance['status'] : 'absent';
            $check_in_time = $attendance ? $attendance['check_in_time'] : '';
            $remarks = $attendance ? $attendance['remarks'] : '';
        ?>
        <tr>
            <td>
                <strong><?= htmlspecialchars($p['full_name']) ?></strong>
                <br><small style="color:#666;"><?= htmlspecialchars($p['email']) ?></small>
            </td>
            <td>
                <select name="status[<?= $p['player_id'] ?>]" class="status-select" data-player="<?= $p['player_id'] ?>">
                    <option value="present" <?= $status == 'present' ? 'selected' : '' ?>>Present</option>
                    <option value="absent" <?= $status == 'absent' ? 'selected' : '' ?>>Absent</option>
                    <option value="late" <?= $status == 'late' ? 'selected' : '' ?>>Late</option>
                </select>
            </td>
            <td>
                <input type="time" name="check_in_time[<?= $p['player_id'] ?>]" 
                       value="<?= htmlspecialchars($check_in_time) ?>"
                       class="check-in-time" 
                       data-player="<?= $p['player_id'] ?>">
            </td>
            <td>
                <textarea name="remarks[<?= $p['player_id'] ?>]" 
                          rows="2" 
                          placeholder="Optional remarks..."><?= htmlspecialchars($remarks) ?></textarea>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
    </table>
</div>

<br>
<button type="submit" name="save_attendance" class="btn-primary">
    <i class="fas fa-save"></i> Save Attendance
</button>

<?php endif; ?>

</form>

</div>

</div>

<script>
// Enable/disable check-in time based on status
document.addEventListener('DOMContentLoaded', function() {
    const statusSelects = document.querySelectorAll('.status-select');
    
    function updateCheckInTime(playerId, status) {
        const checkInInput = document.querySelector(`.check-in-time[data-player="${playerId}"]`);
        if (status === 'present' || status === 'late') {
            checkInInput.disabled = false;
            // Auto-fill with current time if empty
            if (!checkInInput.value) {
                const now = new Date();
                const hours = now.getHours().toString().padStart(2, '0');
                const minutes = now.getMinutes().toString().padStart(2, '0');
                checkInInput.value = `${hours}:${minutes}`;
            }
        } else {
            checkInInput.disabled = true;
            checkInInput.value = '';
        }
    }
    
    statusSelects.forEach(select => {
        const playerId = select.getAttribute('data-player');
        updateCheckInTime(playerId, select.value);
        
        select.addEventListener('change', function() {
            updateCheckInTime(playerId, this.value);
        });
    });
});

// Confirm before saving
document.getElementById('attendanceForm')?.addEventListener('submit', function(e) {
    const sessionSelect = document.getElementById('session_id');
    if (!sessionSelect.value) {
        e.preventDefault();
        alert('Please select a training session first.');
    }
});
</script>

</body>
</html>