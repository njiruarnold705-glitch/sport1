<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$full_name = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'user';

$message = '';
$error = '';

// Send Notification
if (isset($_POST['send_notification'])) {
    $type = $_POST['type'];
    $recipient = trim($_POST['recipient']);
    $message_text = trim($_POST['message']);
    
    if (empty($recipient) || empty($message_text)) {
        $error = "Recipient and message are required.";
    } else {
        if ($type == 'sms') {
            $result = sendSMS($recipient, $message_text);
        } else {
            $result = sendWhatsApp($recipient, $message_text);
        }
        
        if ($result) {
            $message = ucfirst($type) . " notification sent successfully!";
        } else {
            $error = "Failed to send notification.";
        }
    }
}

// Fetch Notifications
$stmt = $conn->prepare("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 50");
$stmt->execute();
$notifications = $stmt->fetchAll();

// Get counts
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM notifications");
$stmt->execute();
$total_notifications = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM notifications WHERE type = 'sms'");
$stmt->execute();
$sms_count = $stmt->fetch()['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM notifications WHERE type = 'whatsapp'");
$stmt->execute();
$whatsapp_count = $stmt->fetch()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Notifications | SportMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .dashboard-container { display: flex; min-height: 100vh; }
        .sidebar { width: 280px; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-right: 1px solid rgba(255,255,255,0.2); padding: 30px 20px; position: fixed; height: 100vh; overflow-y: auto; transition: transform 0.3s ease; z-index: 1000; }
        .sidebar-logo { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.2); }
        .sidebar-logo h2 { color: white; font-size: 1.5rem; }
        .nav-item { padding: 12px 15px; margin: 5px 0; border-radius: 10px; display: flex; align-items: center; gap: 12px; color: white; text-decoration: none; transition: all 0.3s ease; }
        .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.2); transform: translateX(5px); }
        .nav-item i { width: 24px; }
        .logout-btn { margin-top: 30px; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 20px; }
        .main-content { flex: 1; margin-left: 280px; padding: 30px; overflow-x: hidden; }
        .header { background: white; border-radius: 15px; padding: 20px 25px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header h1 { color: #333; font-size: 1.5rem; }
        .user-avatar { width: 50px; height: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; border-radius: 15px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .stat-card h3 { color: #666; font-size: 0.85rem; margin-bottom: 10px; }
        .stat-number { font-size: 2rem; font-weight: bold; color: #667eea; }
        .card { background: white; border-radius: 15px; padding: 20px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px; }
        .card-header h2 { color: #333; font-size: 1.2rem; }
        .btn { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; transition: all 0.3s ease; }
        .btn-primary { background: #667eea; color: white; }
        .btn-success { background: #10b981; color: white; }
        .btn-warning { background: #f59e0b; color: white; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; color: #666; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #f0f0f0; }
        th { color: #666; font-weight: 600; font-size: 0.85rem; }
        .badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 500; }
        .badge-sms { background: #dbeafe; color: #1e40af; }
        .badge-whatsapp { background: #d1fae5; color: #065f46; }
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #d1fae5; color: #065f46; border-left: 4px solid #10b981; }
        .alert-error { background: #fee2e2; color: #991b1b; border-left: 4px solid #ef4444; }
        .mobile-menu-btn { display: none; position: fixed; bottom: 20px; right: 20px; width: 56px; height: 56px; background: white; border-radius: 50%; box-shadow: 0 2px 10px rgba(0,0,0,0.2); border: none; cursor: pointer; z-index: 1001; color: #667eea; font-size: 1.5rem; }
        .overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 999; }
        .empty-state { text-align: center; padding: 40px; color: #999; }
        .two-columns { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .mobile-menu-btn { display: flex; align-items: center; justify-content: center; }
            .overlay.active { display: block; }
            .two-columns { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <button class="mobile-menu-btn" id="menuToggle"><i class="fas fa-bars"></i></button>
    <div class="overlay" id="overlay"></div>
    
    <div class="sidebar" id="sidebar">
        <div class="sidebar-logo"><h2><i class="fas fa-futbol"></i> SportMS</h2></div>
        <nav>
            <a href="dashboard.php" class="nav-item"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
            <a href="players.php" class="nav-item"><i class="fas fa-users"></i><span>Players</span></a>
            <a href="coaches.php" class="nav-item"><i class="fas fa-chalkboard-user"></i><span>Coaches</span></a>
            <a href="payments.php" class="nav-item"><i class="fas fa-credit-card"></i><span>Payments</span></a>
            <a href="sessions.php" class="nav-item"><i class="fas fa-calendar-alt"></i><span>Sessions</span></a>
            <a href="notifications.php" class="nav-item active"><i class="fas fa-bell"></i><span>Notifications</span></a>
            <div class="logout-btn"><a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></div>
        </nav>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1><i class="fas fa-bell"></i> Notifications</h1>
            <div class="user-avatar"><?= strtoupper(substr($full_name, 0, 1)) ?></div>
        </div>
        
        <?php if ($message): ?><div class="alert alert-success"><?= e($message) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
        
        <div class="stats-grid">
            <div class="stat-card"><h3>Total Sent</h3><div class="stat-number"><?= $total_notifications ?></div></div>
            <div class="stat-card"><h3>SMS</h3><div class="stat-number"><?= $sms_count ?></div></div>
            <div class="stat-card"><h3>WhatsApp</h3><div class="stat-number"><?= $whatsapp_count ?></div></div>
        </div>
        
        <div class="two-columns">
            <!-- Send Notification Form -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-paper-plane"></i> Send Notification</h2>
                </div>
                <form method="POST">
                    <div class="form-group">
                        <label>Type *</label>
                        <select name="type" required>
                            <option value="sms">SMS</option>
                            <option value="whatsapp">WhatsApp</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Recipient (Phone Number) *</label>
                        <input type="tel" name="recipient" placeholder="+254700000000" required>
                    </div>
                    <div class="form-group">
                        <label>Message *</label>
                        <textarea name="message" rows="5" placeholder="Type your message here..." required></textarea>
                    </div>
                    <button type="submit" name="send_notification" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
                </form>
            </div>
            
            <!-- Quick Send to Players -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-users"></i> Quick Send to Players</h2>
                </div>
                <?php
                $stmt = $conn->prepare("SELECT phone, full_name FROM users WHERE role = 'player' AND status = 'active' LIMIT 10");
                $stmt->execute();
                $players_list = $stmt->fetchAll();
                ?>
                <div class="table-responsive">
                    <table>
                        <thead><tr><th>Player</th><th>Phone</th><th>Action</th></tr></thead>
                        <tbody>
                            <?php foreach ($players_list as $player): ?>
                            <tr>
                                <td><?= e($player['full_name']) ?></td>
                                <td><?= e($player['phone']) ?></td>
                                <td><button class="btn btn-sm btn-primary" onclick="setRecipient('<?= e($player['phone']) ?>')"><i class="fas fa-envelope"></i> Message</button></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Notification History -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-history"></i> Notification History</h2>
            </div>
            <div class="table-responsive">
                <?php if (count($notifications) > 0): ?>
                    <table>
                        <thead>
                            <tr><th>Type</th><th>Recipient</th><th>Message</th><th>Status</th><th>Date</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($notifications as $notification): ?>
                            <tr>
                                <td><span class="badge badge-<?= $notification['type'] ?>"><?= strtoupper($notification['type']) ?></span></td>
                                <td><?= e($notification['recipient_phone']) ?></td>
                                <td><small><?= substr(e($notification['message']), 0, 60) ?>...</small></td>
                                <td><span class="badge badge-<?= $notification['status'] ?>"><?= ucfirst($notification['status']) ?></span></td>
                                <td><?= date('M d, Y h:i A', strtotime($notification['created_at'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state"><i class="fas fa-bell-slash" style="font-size: 3rem; color: #ddd;"></i><p>No notifications sent yet</p></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function setRecipient(phone) {
    document.querySelector('input[name="recipient"]').value = phone;
    document.querySelector('select[name="type"]').focus();
}

const menuToggle = document.getElementById('menuToggle');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

if(menuToggle) {
    menuToggle.onclick = () => {
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    };
}
if(overlay) {
    overlay.onclick = () => {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    };
}
</script>
</body>
</html>