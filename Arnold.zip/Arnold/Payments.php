<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$full_name = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'user';

if ($role !== 'admin' && $role !== 'coach') {
    die("Access denied.");
}

/* SAFE ESCAPE */
function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

$message = '';
$error = '';

/* ========================
   ADD PAYMENT
======================== */
if (isset($_POST['add_payment'])) {
    $user_id = (int)$_POST['user_id'];
    $amount = (float)$_POST['amount'];
    $payment_type = $_POST['payment_type'] ?? 'other';
    $payment_method = $_POST['payment_method'] ?? 'cash';
    $transaction_code = trim($_POST['transaction_code']);

    if ($user_id && $amount > 0) {
        $stmt = $conn->prepare("
            INSERT INTO payments (user_id, amount, payment_type, payment_method, transaction_code, status, created_at)
            VALUES (?, ?, ?, ?, ?, 'pending', NOW())
        ");

        if ($stmt->execute([$user_id, $amount, $payment_type, $payment_method, $transaction_code])) {
            $message = "Payment recorded successfully!";
        } else {
            $error = "Failed to record payment.";
        }
    } else {
        $error = "Invalid payment data.";
    }
}

/* ========================
   UPDATE STATUS
======================== */
if (isset($_POST['update_status'])) {
    $stmt = $conn->prepare("UPDATE payments SET status=? WHERE payment_id=?");

    if ($stmt->execute([$_POST['status'], $_POST['payment_id']])) {
        $message = "Payment updated!";
    } else {
        $error = "Failed to update payment.";
    }
}

/* ========================
   FETCH PAYMENTS
======================== */
$search = $_GET['search'] ?? '';

$sql = "SELECT p.*, u.full_name 
        FROM payments p 
        JOIN users u ON p.user_id = u.user_id";

$params = [];

if (!empty($search)) {
    $sql .= " WHERE u.full_name LIKE :search OR p.transaction_code LIKE :search";
    $params[':search'] = "%$search%";
}

$sql .= " ORDER BY p.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$payments = $stmt->fetchAll();

/* ========================
   STATS
======================== */
$total_revenue = $conn->query("SELECT SUM(amount) FROM payments WHERE status='completed'")->fetchColumn() ?? 0;
$pending_count = $conn->query("SELECT COUNT(*) FROM payments WHERE status='pending'")->fetchColumn();

/* ========================
   PLAYERS
======================== */
$players = $conn->query("SELECT user_id, full_name FROM users WHERE role='player' ORDER BY full_name")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
<title>Payments | SportMS</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
body {
    font-family: 'Segoe UI';
    background: linear-gradient(135deg,#667eea,#764ba2);
    margin:0;
    color:white;
}

.container {padding:20px;}

.card {
    background:white;
    color:black;
    border-radius:12px;
    padding:20px;
    margin-bottom:20px;
}

table {width:100%; border-collapse:collapse;}
th,td {padding:10px; border-bottom:1px solid #eee;}

.btn {padding:8px 12px; border:none; border-radius:6px; cursor:pointer;}
.btn-primary {background:#667eea; color:white;}
.btn-success {background:#10b981; color:white;}

.badge {
    padding:4px 10px;
    border-radius:20px;
    font-size:12px;
}

.completed {background:#d1fae5; color:#065f46;}
.pending {background:#fed7aa; color:#92400e;}

.modal {
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0.5);
    align-items:center;
    justify-content:center;
}

.modal.active {display:flex;}

.modal-box {
    background:white;
    color:black;
    padding:20px;
    border-radius:10px;
    width:90%;
    max-width:400px;
}
</style>
</head>

<body>

<div class="container">

<h2><i class="fas fa-credit-card"></i> Payments</h2>

<?php if($message): ?><div class="card"><?= e($message) ?></div><?php endif; ?>
<?php if($error): ?><div class="card"><?= e($error) ?></div><?php endif; ?>

<div class="card">
    <h3>Total Revenue: KES <?= number_format($total_revenue) ?></h3>
    <p>Pending Payments: <?= $pending_count ?></p>
</div>

<div class="card">

<button class="btn btn-primary" onclick="openModal()">
    <i class="fas fa-plus"></i> Add Payment
</button>

<br><br>

<form method="GET">
    <input type="text" name="search" placeholder="Search..." value="<?= e($search) ?>">
    <button class="btn btn-primary">Search</button>
</form>

<br>

<table>
<thead>
<tr>
<th>User</th>
<th>Amount</th>
<th>Status</th>
<th>Date</th>
<th>Action</th>
</tr>
</thead>

<tbody>
<?php if ($payments): ?>
    <?php foreach($payments as $p): ?>
    <tr>
        <td><?= e($p['full_name']) ?></td>
        <td><strong>KES <?= number_format($p['amount']) ?></strong></td>
        <td>
            <span class="badge <?= $p['status'] ?>">
                <?= ucfirst($p['status']) ?>
            </span>
        </td>
        <td><?= date('M d, Y', strtotime($p['created_at'])) ?></td>
        <td>
            <?php if($p['status']=='pending'): ?>
            <form method="POST">
                <input type="hidden" name="payment_id" value="<?= $p['payment_id'] ?>">
                <input type="hidden" name="status" value="completed">
                <button name="update_status" class="btn btn-success">Approve</button>
            </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
<?php else: ?>
<tr><td colspan="5">No payments found</td></tr>
<?php endif; ?>
</tbody>
</table>

</div>

</div>

<!-- MODAL -->
<div class="modal" id="modal">
<div class="modal-box">
<h3>Add Payment</h3>

<form method="POST">

<select name="user_id" required>
<?php foreach($players as $pl): ?>
<option value="<?= $pl['user_id'] ?>"><?= e($pl['full_name']) ?></option>
<?php endforeach; ?>
</select><br><br>

<input type="number" name="amount" placeholder="Amount" required><br><br>

<select name="payment_type">
<option value="training">Training</option>
<option value="registration">Registration</option>
<option value="other">Other</option>
</select><br><br>

<select name="payment_method">
<option value="mpesa">M-Pesa</option>
<option value="cash">Cash</option>
<option value="bank">Bank</option>
</select><br><br>

<input type="text" name="transaction_code" placeholder="Transaction Code"><br><br>

<button name="add_payment" class="btn btn-primary">Save</button>

</form>

<br>
<button onclick="closeModal()">Close</button>

</div>
</div>

<script>
function openModal(){ document.getElementById('modal').classList.add('active'); }
function closeModal(){ document.getElementById('modal').classList.remove('active'); }
</script>

</body>
</html>