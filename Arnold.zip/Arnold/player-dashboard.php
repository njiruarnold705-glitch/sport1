<?php
require_once 'config.php';

if (!isLoggedIn()) redirect('login.php');

if ($_SESSION['role'] !== 'player') {
    if ($_SESSION['role'] === 'admin') redirect('dashboard.php');
    else redirect('coach-dashboard.php');
}

$user_id = $_SESSION['user_id'];
$page = $_GET['page'] ?? 'dashboard';

// DATA
try {
    $stmt = $conn->prepare("SELECT * FROM players WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $player = $stmt->fetch();

    $stmt = $conn->prepare("SELECT * FROM payments WHERE user_id = ? ORDER BY payment_date DESC");
    $stmt->execute([$user_id]);
    $payments = $stmt->fetchAll();

    $stmt = $conn->query("
        SELECT ts.*, u.full_name as coach_name 
        FROM training_sessions ts 
        JOIN users u ON ts.coach_id = u.user_id 
        ORDER BY ts.session_date DESC
    ");
    $sessions = $stmt->fetchAll();

    $stmt = $conn->prepare("SELECT SUM(amount) as total FROM payments WHERE user_id = ? AND status='completed'");
    $stmt->execute([$user_id]);
    $total_paid = $stmt->fetch()['total'] ?? 0;

} catch (Exception $e) {
    die("Error loading dashboard");
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Player Dashboard</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
* {margin:0; padding:0; box-sizing:border-box;}

body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#667eea,#764ba2);
}

/* LAYOUT */
.container {
    display:flex;
    min-height:100vh;
}

/* SIDEBAR */
.sidebar {
    width:260px;
    background: rgba(0,0,0,0.3);
    backdrop-filter: blur(10px);
    padding:20px;
    color:white;
}

.sidebar h2 {margin-bottom:5px;}
.sidebar p {font-size:14px; opacity:0.7;}

.sidebar a {
    display:flex;
    align-items:center;
    gap:10px;
    padding:10px;
    margin:8px 0;
    border-radius:8px;
    text-decoration:none;
    color:white;
    transition:0.3s;
}

.sidebar a:hover,
.sidebar a.active {
    background:#10b981;
}

/* MAIN */
.main {
    flex:1;
    padding:25px;
}

/* HEADER */
.header {
    background:white;
    padding:15px 20px;
    border-radius:12px;
    margin-bottom:20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.avatar {
    width:45px;
    height:45px;
    border-radius:50%;
    background:#667eea;
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-weight:bold;
}

/* CARDS */
.card {
    background:white;
    border-radius:12px;
    padding:20px;
    margin-bottom:20px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

/* STATS */
.stat {
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.stat h2 {color:#10b981;}

/* TABLE */
table {
    width:100%;
    border-collapse:collapse;
}

th {
    text-align:left;
    padding:10px;
    background:#f1f5f9;
    font-size:14px;
}

td {
    padding:10px;
    border-bottom:1px solid #eee;
}

tr:hover {background:#f9fafb;}

/* BADGE */
.badge {
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
}

.success {background:#d1fae5; color:#065f46;}
.pending {background:#fef3c7; color:#92400e;}

/* BUTTON */
.btn {
    display:inline-block;
    padding:8px 12px;
    background:#ef4444;
    color:white;
    border-radius:8px;
    text-decoration:none;
}

/* MOBILE */
@media(max-width:768px){
    .container {flex-direction:column;}
    .sidebar {width:100%;}
}
</style>
</head>

<body>

<div class="container">

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>⚽ SportMS</h2>
    <p><?= htmlspecialchars($_SESSION['full_name']) ?></p>
    <hr>

    <a href="?page=dashboard" class="<?= $page=='dashboard'?'active':'' ?>">
        <i class="fas fa-home"></i> Dashboard
    </a>

    <a href="?page=profile" class="<?= $page=='profile'?'active':'' ?>">
        <i class="fas fa-user"></i> Profile
    </a>

    <a href="?page=payments" class="<?= $page=='payments'?'active':'' ?>">
        <i class="fas fa-credit-card"></i> Payments
    </a>

    <a href="?page=training" class="<?= $page=='training'?'active':'' ?>">
        <i class="fas fa-futbol"></i> Training
    </a>

    <br>
    <a href="logout.php" class="btn">Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="header">
    <h2><?= ucfirst($page) ?></h2>
    <div class="avatar"><?= strtoupper(substr($_SESSION['full_name'],0,1)) ?></div>
</div>

<?php if ($page == 'dashboard'): ?>

<div class="card stat">
    <div>
        <h3>Total Paid</h3>
        <h2>KES <?= number_format($total_paid) ?></h2>
    </div>
    <i class="fas fa-wallet fa-2x"></i>
</div>

<?php elseif ($page == 'profile'): ?>

<div class="card">
    <p><strong>Email:</strong> <?= htmlspecialchars($_SESSION['email']) ?></p>
    <p><strong>Phone:</strong> <?= htmlspecialchars($_SESSION['phone']) ?></p>

    <?php if ($player): ?>
        <p><strong>Position:</strong> <?= $player['position'] ?? 'N/A' ?></p>
        <p><strong>Jersey:</strong> <?= $player['jersey_number'] ?? 'N/A' ?></p>
    <?php endif; ?>
</div>

<?php elseif ($page == 'payments'): ?>

<div class="card">
<table>
<tr><th>Date</th><th>Amount</th><th>Status</th></tr>

<?php if ($payments): ?>
<?php foreach ($payments as $p): ?>
<tr>
<td><?= date('M d, Y', strtotime($p['payment_date'])) ?></td>
<td><strong>KES <?= number_format($p['amount']) ?></strong></td>
<td>
<span class="badge <?= $p['status']=='completed'?'success':'pending' ?>">
<?= ucfirst($p['status']) ?>
</span>
</td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr><td colspan="3">No payments yet</td></tr>
<?php endif; ?>

</table>
</div>

<?php elseif ($page == 'training'): ?>

<div class="card">
<table>
<tr><th>Title</th><th>Coach</th><th>Date</th></tr>

<?php if ($sessions): ?>
<?php foreach ($sessions as $s): ?>
<tr>
<td><?= htmlspecialchars($s['title']) ?></td>
<td><?= htmlspecialchars($s['coach_name']) ?></td>
<td><?= date('M d, Y', strtotime($s['session_date'])) ?></td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr><td colspan="3">No sessions available</td></tr>
<?php endif; ?>

</table>
</div>

<?php endif; ?>

</div>
</div>

</body>
</html>