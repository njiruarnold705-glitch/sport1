<?php
require_once 'config.php';

// DEBUG (REMOVE IN PRODUCTION)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Handle login request (AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    header('Content-Type: application/json');

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!$email || !$password) {
        echo json_encode(['success' => false, 'message' => 'Enter email and password']);
        exit;
    }

    try {
        // Fetch user
        $stmt = $conn->prepare("
            SELECT user_id, full_name, email, phone, password_hash, role, status 
            FROM users WHERE email = ?
        ");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            echo json_encode(['success' => false, 'message' => 'Email not found']);
            exit;
        }

        if ($user['status'] !== 'active') {
            echo json_encode(['success' => false, 'message' => 'Account inactive']);
            exit;
        }

        if (!verifyPassword($password, $user['password_hash'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid password']);
            exit;
        }

        // Login success
        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['phone'] = $user['phone'];
        $_SESSION['role'] = $user['role'];

        // Update last login
        $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?");
        $stmt->execute([$user['user_id']]);

        // Redirect
        $redirect = match($user['role']) {
            'admin' => 'dashboard.php',
            'coach' => 'coach-dashboard.php',
            default => 'player-dashboard.php'
        };

        echo json_encode([
            'success' => true,
            'message' => 'Login successful!',
            'redirect' => $redirect
        ]);
        exit;

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Login | Sport Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
        }

        /* Background Pattern */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="80" cy="40" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="80" r="2" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
            opacity: 0.3;
            pointer-events: none;
        }

        /* Main Container */
        .login-container {
            width: 100%;
            max-width: 440px;
            position: relative;
            z-index: 1;
            animation: slideUp 0.5s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Card */
        .login-card {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 28px;
            padding: 48px 40px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            transition: transform 0.3s ease;
        }

        .login-card:hover {
            transform: translateY(-5px);
        }

        /* Header */
        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .logo-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            box-shadow: 0 10px 25px -5px rgba(102, 126, 234, 0.4);
        }

        .logo-icon i {
            font-size: 40px;
            color: white;
        }

        .login-header h2 {
            color: #1e293b;
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .login-header p {
            color: #64748b;
            font-size: 14px;
        }

        /* Form */
        .form-group {
            margin-bottom: 24px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #334155;
            font-size: 13px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-group label i {
            margin-right: 8px;
            color: #667eea;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            font-size: 18px;
        }

        .form-group input {
            width: 100%;
            padding: 14px 16px 14px 48px;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: white;
            font-family: inherit;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-group input:hover {
            border-color: #667eea;
        }

        /* Toggle Password */
        .toggle-password {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #94a3b8;
            transition: color 0.3s ease;
            z-index: 2;
        }

        .toggle-password:hover {
            color: #667eea;
        }

        /* Button */
        .login-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 14px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 8px;
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px -5px rgba(102, 126, 234, 0.4);
        }

        .login-btn:active {
            transform: translateY(0);
        }

        /* Register Link */
        .register-link {
            text-align: center;
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid #e2e8f0;
        }

        .register-link p {
            color: #64748b;
            font-size: 14px;
        }

        .register-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .register-link a:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        /* Message Alert */
        .alert {
            padding: 14px 16px;
            border-radius: 14px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: #d1fae5;
            border-left: 4px solid #10b981;
            color: #065f46;
        }

        .alert-error {
            background: #fee2e2;
            border-left: 4px solid #ef4444;
            color: #991b1b;
        }

        .alert i {
            font-size: 18px;
        }

        /* Loading State */
        .login-btn.loading {
            opacity: 0.7;
            cursor: not-allowed;
        }

        .login-btn.loading i {
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /* Demo Credentials */
        .demo-credentials {
            background: #f8fafc;
            border-radius: 14px;
            padding: 16px;
            margin-top: 24px;
            border: 1px solid #e2e8f0;
        }

        .demo-credentials p {
            font-size: 12px;
            color: #64748b;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .demo-items {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .demo-item {
            flex: 1;
            background: white;
            padding: 8px 12px;
            border-radius: 10px;
            font-size: 11px;
            color: #334155;
            border: 1px solid #e2e8f0;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .demo-item:hover {
            border-color: #667eea;
            background: #f1f5f9;
        }

        .demo-item strong {
            color: #667eea;
            display: block;
            margin-bottom: 4px;
        }

        /* Responsive */
        @media (max-width: 480px) {
            .login-card {
                padding: 32px 24px;
            }
            
            .login-header h2 {
                font-size: 28px;
            }
            
            .form-group input {
                padding: 12px 14px 12px 44px;
                font-size: 14px;
            }
            
            .logo-icon {
                width: 70px;
                height: 70px;
            }
            
            .logo-icon i {
                font-size: 32px;
            }
            
            .demo-items {
                flex-direction: column;
            }
        }

        /* Password strength indicator (optional) */
        .password-hint {
            font-size: 11px;
            color: #94a3b8;
            margin-top: 6px;
        }
    </style>
</head>

<body>

<div class="login-container">
    <div class="login-card">
        <div class="login-header">
            <div class="logo-icon">
                <i class="fas fa-futbol"></i>
            </div>
            <h2>Welcome Back</h2>
            <p>Sign in to access your account</p>
        </div>

        <div id="msg"></div>

        <form id="loginForm">
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email Address</label>
                <div class="input-wrapper">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" placeholder="you@example.com" required autocomplete="email">
                </div>
            </div>

            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" id="password" placeholder="Enter your password" required autocomplete="current-password">
                    <i class="fas fa-eye toggle-password" id="togglePassword"></i>
                </div>
            </div>

            <button type="submit" class="login-btn">
                <i class="fas fa-sign-in-alt"></i>
                <span>Sign In</span>
            </button>
        </form>

        <!-- Demo Credentials (Helpful for testing) -->
        <div class="demo-credentials">
            <p><i class="fas fa-info-circle"></i> Demo Accounts (Click to auto-fill)</p>
            <div class="demo-items">
                <div class="demo-item" onclick="fillCredentials('admin@sportsystem.com', 'password')">
                    <strong>Admin</strong>
                    admin@sportsystem.com
                </div>
                <div class="demo-item" onclick="fillCredentials('coach@sportsystem.com', 'password')">
                    <strong>Coach</strong>
                    coach@sportsystem.com
                </div>
                <div class="demo-item" onclick="fillCredentials('player@sportsystem.com', 'password')">
                    <strong>Player</strong>
                    player@sportsystem.com
                </div>
            </div>
        </div>

        <div class="register-link">
            <p>Don't have an account? <a href="register.php">Create Account</a></p>
        </div>
    </div>
</div>

<script>
// Toggle password visibility
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('password');

if (togglePassword && passwordInput) {
    togglePassword.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
}

// Auto-fill demo credentials
function fillCredentials(email, password) {
    document.querySelector('input[name="email"]').value = email;
    document.querySelector('input[name="password"]').value = password;
    
    // Highlight the filled fields
    const emailField = document.querySelector('input[name="email"]');
    const passwordField = document.querySelector('input[name="password"]');
    
    emailField.style.borderColor = '#10b981';
    passwordField.style.borderColor = '#10b981';
    
    setTimeout(() => {
        emailField.style.borderColor = '#e2e8f0';
        passwordField.style.borderColor = '#e2e8f0';
    }, 2000);
}

// Handle form submission
document.getElementById('loginForm').addEventListener('submit', function(e){
    e.preventDefault();

    let formData = new FormData(this);
    let submitBtn = document.querySelector('.login-btn');
    let originalText = submitBtn.innerHTML;
    
    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner"></i> Signing in...';
    submitBtn.classList.add('loading');
    submitBtn.disabled = true;

    fetch('', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        let msgDiv = document.getElementById('msg');

        if (data.success) {
            msgDiv.innerHTML = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span>${data.message}</span>
                </div>
            `;
            
            setTimeout(() => {
                window.location = data.redirect;
            }, 1000);
        } else {
            msgDiv.innerHTML = `
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>${data.message}</span>
                </div>
            `;
            
            // Reset button
            submitBtn.innerHTML = originalText;
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
            
            // Shake effect on error
            const card = document.querySelector('.login-card');
            card.style.animation = 'shake 0.5s ease';
            setTimeout(() => {
                card.style.animation = '';
            }, 500);
            
            // Auto-hide error after 5 seconds
            setTimeout(() => {
                if (msgDiv.firstChild) {
                    msgDiv.innerHTML = '';
                }
            }, 5000);
        }
    })
    .catch(() => {
        let msgDiv = document.getElementById('msg');
        msgDiv.innerHTML = `
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span>Network error. Please try again.</span>
            </div>
        `;
        
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;
    });
});

// Add shake animation
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
`;
document.head.appendChild(style);
</script>

</body>
</html>