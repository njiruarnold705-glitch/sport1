<?php
require_once 'config.php';
session_start();

// SAFE DEFAULTS (prevents errors)
$message = $message ?? '';
$search = $_GET['search'] ?? '';
$players = $players ?? [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Coach Players</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
* {margin:0; padding:0; box-sizing:border-box;}

body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#667eea,#764ba2);
    color:white;
}

.sidebar {
    width:260px;
    height:100vh;
    position:fixed;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    padding:25px;
}

.sidebar h2 {margin-bottom:5px;}
.sidebar p {font-size:14px; color:#ddd; margin-bottom:15px;}

.sidebar a {
    display:block;
    padding:12px;
    margin:6px 0;
    border-radius:10px;
    color:white;
    text-decoration:none;
    transition:0.3s;
}

.sidebar a:hover,
.sidebar a.active {
    background: rgba(255,255,255,0.2);
}

.main {
    margin-left:280px;
    padding:30px;
}

.header {
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

.card {
    background:white;
    color:#1e293b;
    border-radius:15px;
    padding:20px;
    margin-bottom:20px;
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
}

.search-box {
    display:flex;
    gap:10px;
    flex-wrap:wrap;
}

.search-box input {
    flex:1;
    padding:10px;
    border-radius:8px;
    border:1px solid #ddd;
}

.search-box button {
    padding:10px 20px;
    border:none;
    border-radius:8px;
    background:#667eea;
    color:white;
    cursor:pointer;
}

.search-box button:hover {
    background:#5a67d8;
}

table {
    width:100%;
    border-collapse:collapse;
}

th {
    background:#f1f5f9;
    text-align:left;
    padding:12px;
}

td {
    padding:12px;
    border-bottom:1px solid #eee;
}

tr:hover {
    background:#f9fafb;
}

.btn-danger {
    background:#ef4444;
    color:white;
    padding:6px 12px;
    border-radius:6px;
    text-decoration:none;
}

.btn-danger:hover {
    background:#dc2626;
}

.alert {
    padding:15px;
    border-radius:10px;
    margin-bottom:15px;
}

.success {background:#d1fae5; color:#065f46;}
.error {background:#fee2e2; color:#991b1b;}

.empty {
    text-align:center;
    padding:30px;
    color:#999;
}

@media(max-width:768px){
    .sidebar {
        position:relative;
        width:100%;
        height:auto;
    }
    .main {
        margin-left:0;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2><i class="fas fa-user"></i> Coach Panel</h2>
    <p><?= htmlspecialchars($_SESSION['full_name'] ?? 'Coach') ?></p>
    <hr>

    <a href="coach-dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="coach-sessions.php"><i class="fas fa-calendar"></i> Sessions</a>
    <a href="coach-attendance.php"><i class="fas fa-check"></i> Attendance</a>
    <a href="coach-players.php" class="active"><i class="fas fa-users"></i> Players</a>

    <br>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="header">
    <h1><i class="fas fa-users"></i> Players</h1>
</div>

<!-- MESSAGE -->
<?php if (!empty($message)): ?>
<div class="alert success">
    <?= htmlspecialchars($message) ?>
</div>
<?php endif; ?>

<!-- SEARCH -->
<div class="card">
    <form method="GET" class="search-box">
        <input type="text" name="search" placeholder="Search players..." value="<?= htmlspecialchars($search) ?>">
        <button type="submit"><i class="fas fa-search"></i> Search</button>
    </form>
</div>

<!-- TABLE -->
<div class="card">
    <h3>All Players</h3>

    <?php if (!empty($players)): ?>
    <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Position</th>
            <th>Jersey</th>
            <th>Action</th>
        </tr>

        <?php foreach ($players as $p): ?>
        <tr>
            <td><?= htmlspecialchars($p['full_name']) ?></td>
            <td><?= htmlspecialchars($p['email']) ?></td>
            <td><?= htmlspecialchars($p['phone']) ?></td>
            <td><?= htmlspecialchars($p['position'] ?? 'N/A') ?></td>
            <td><?= htmlspecialchars($p['jersey_number'] ?? 'N/A') ?></td>
            <td>
                <a href="?delete=<?= $p['player_id'] ?>" 
                   onclick="return confirm('Remove this player?')" 
                   class="btn-danger">
                   <i class="fas fa-trash"></i> Remove
                </a>
            </td>
        </tr>
        <?php endforeach; ?>

    </table>
    <?php else: ?>
        <div class="empty">
            <i class="fas fa-users" style="font-size:40px;"></i>
            <p>No players found</p>
        </div>
    <?php endif; ?>

</div>

</div>

</body>
</html>