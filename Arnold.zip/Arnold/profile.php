<?php
require_once 'config.php';

if (!isLoggedIn()) redirect('login.php');

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'user';

// Fetch user
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Fetch player details if role is player
$player = null;
if ($role === 'player') {
    $stmt = $conn->prepare("SELECT * FROM players WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $player = $stmt->fetch();
}

// Handle profile update
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    
    if (empty($full_name) || empty($phone)) {
        $error = "Name and phone are required.";
    } else {
        $stmt = $conn->prepare("UPDATE users SET full_name = ?, phone = ?, updated_at = NOW() WHERE user_id = ?");
        if ($stmt->execute([$full_name, $phone, $user_id])) {
            $_SESSION['full_name'] = $full_name;
            $message = "Profile updated successfully!";
            // Refresh user data
            $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();
        } else {
            $error = "Failed to update profile.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>My Profile | Sport Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            position: relative;
        }

        /* Background Pattern */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="80" cy="40" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="80" r="2" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
            opacity: 0.3;
            pointer-events: none;
        }

        /* Main Container */
        .profile-container {
            max-width: 800px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
            animation: slideUp 0.5s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Header */
        .profile-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .avatar {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 4px solid rgba(255, 255, 255, 0.2);
        }

        .avatar i {
            font-size: 60px;
            color: white;
        }

        .profile-header h1 {
            color: white;
            font-size: 28px;
            margin-bottom: 8px;
        }

        .role-badge {
            display: inline-block;
            padding: 6px 16px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            font-size: 14px;
            color: white;
        }

        /* Card */
        .card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e2e8f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-title i {
            color: #667eea;
        }

        /* Info Grid */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .info-item {
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .info-label {
            font-size: 12px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .info-label i {
            font-size: 12px;
        }

        .info-value {
            font-size: 16px;
            font-weight: 500;
            color: #1e293b;
        }

        /* Form */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #334155;
            font-size: 13px;
            font-weight: 600;
        }

        .form-group label i {
            margin-right: 8px;
            color: #667eea;
        }

        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        /* Buttons */
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            background: #f1f5f9;
            color: #334155;
        }

        .btn-secondary:hover {
            background: #e2e8f0;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .btn-sm {
            padding: 8px 16px;
            font-size: 13px;
        }

        /* Alert Messages */
        .alert {
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: #d1fae5;
            border-left: 4px solid #10b981;
            color: #065f46;
        }

        .alert-error {
            background: #fee2e2;
            border-left: 4px solid #ef4444;
            color: #991b1b;
        }

        .alert i {
            font-size: 18px;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 12px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        /* Back Link */
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: white;
            text-decoration: none;
            margin-top: 20px;
            transition: all 0.3s ease;
        }

        .back-link:hover {
            gap: 12px;
        }

        /* Responsive */
        @media (max-width: 640px) {
            .profile-container {
                padding: 0;
            }
            
            .card {
                padding: 20px;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
            
            .avatar {
                width: 100px;
                height: 100px;
            }
            
            .avatar i {
                font-size: 50px;
            }
            
            .profile-header h1 {
                font-size: 24px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn {
                justify-content: center;
            }
        }

        /* Edit Mode Toggle */
        .edit-toggle {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .view-mode, .edit-mode {
            transition: all 0.3s ease;
        }

        .edit-mode {
            display: none;
        }

        .edit-mode.active {
            display: block;
        }

        .view-mode.hide {
            display: none;
        }

        /* Stats */
        .stats-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #f1f5f9;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            color: #64748b;
        }
    </style>
</head>
<body>

<div class="profile-container">
    <!-- Header -->
    <div class="profile-header">
        <div class="avatar">
            <i class="fas fa-user-circle"></i>
        </div>
        <h1><?= htmlspecialchars($user['full_name']) ?></h1>
        <span class="role-badge">
            <i class="fas <?= $role === 'admin' ? 'fa-crown' : ($role === 'coach' ? 'fa-chalkboard-user' : 'fa-user') ?>"></i>
            <?= ucfirst($role) ?>
        </span>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <span><?= htmlspecialchars($message) ?></span>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <span><?= htmlspecialchars($error) ?></span>
        </div>
    <?php endif; ?>

    <!-- View Mode -->
    <div id="viewMode" class="view-mode">
        <!-- Account Information -->
        <div class="card">
            <div class="card-title">
                <i class="fas fa-user-circle"></i>
                <span>Account Information</span>
            </div>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-user"></i> Full Name</div>
                    <div class="info-value"><?= htmlspecialchars($user['full_name']) ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-envelope"></i> Email Address</div>
                    <div class="info-value"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-phone"></i> Phone Number</div>
                    <div class="info-value"><?= htmlspecialchars($user['phone']) ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-calendar-alt"></i> Member Since</div>
                    <div class="info-value"><?= date('F j, Y', strtotime($user['created_at'])) ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-clock"></i> Last Login</div>
                    <div class="info-value"><?= $user['last_login'] ? date('F j, Y g:i A', strtotime($user['last_login'])) : 'Never' ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-circle"></i> Status</div>
                    <div class="info-value">
                        <span class="stats-badge" style="background: <?= $user['status'] === 'active' ? '#d1fae5' : '#fee2e2' ?>; color: <?= $user['status'] === 'active' ? '#065f46' : '#991b1b' ?>">
                            <i class="fas <?= $user['status'] === 'active' ? 'fa-check-circle' : 'fa-times-circle' ?>"></i>
                            <?= ucfirst($user['status']) ?>
                        </span>
                    </div>
                </div>
            </div>
            <div class="action-buttons">
                <button class="btn btn-primary" onclick="toggleEdit()">
                    <i class="fas fa-edit"></i> Edit Profile
                </button>
                <a href="change-password.php" class="btn btn-secondary">
                    <i class="fas fa-key"></i> Change Password
                </a>
            </div>
        </div>

        <!-- Player Details (if role is player) -->
        <?php if ($role === 'player' && $player): ?>
        <div class="card">
            <div class="card-title">
                <i class="fas fa-futbol"></i>
                <span>Player Details</span>
            </div>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-user-tag"></i> Position</div>
                    <div class="info-value"><?= htmlspecialchars($player['position'] ?? 'Not specified') ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-hashtag"></i> Jersey Number</div>
                    <div class="info-value"><?= htmlspecialchars($player['jersey_number'] ?? 'Not assigned') ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-ruler"></i> Height</div>
                    <div class="info-value"><?= htmlspecialchars($player['height_cm'] ?? 'N/A') ?> cm</div>
                </div>
                <div class="info-item">
                    <div class="info-label"><i class="fas fa-weight-hanging"></i> Weight</div>
                    <div class="info-value"><?= htmlspecialchars($player['weight_kg'] ?? 'N/A') ?> kg</div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Edit Mode -->
    <div id="editMode" class="edit-mode">
        <div class="card">
            <div class="card-title">
                <i class="fas fa-edit"></i>
                <span>Edit Profile</span>
            </div>
            <form method="POST">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Full Name</label>
                    <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" value="<?= htmlspecialchars($user['email']) ?>" disabled>
                    <small style="color: #64748b; font-size: 12px;">Email cannot be changed</small>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-phone"></i> Phone Number</label>
                    <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required>
                </div>
                <div class="action-buttons">
                    <button type="submit" name="update_profile" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="toggleEdit()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Back Link -->
    <div style="text-align: center;">
        <a href="<?= $role === 'admin' ? 'dashboard.php' : ($role === 'coach' ? 'coach-dashboard.php' : 'player-dashboard.php') ?>" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</div>

<script>
function toggleEdit() {
    const viewMode = document.getElementById('viewMode');
    const editMode = document.getElementById('editMode');
    
    if (viewMode.classList.contains('hide')) {
        viewMode.classList.remove('hide');
        editMode.classList.remove('active');
    } else {
        viewMode.classList.add('hide');
        editMode.classList.add('active');
    }
}

// Check for update message to automatically show view mode
<?php if (isset($_POST['update_profile']) && $message): ?>
// Successfully updated, show view mode
document.addEventListener('DOMContentLoaded', function() {
    const viewMode = document.getElementById('viewMode');
    const editMode = document.getElementById('editMode');
    viewMode.classList.remove('hide');
    editMode.classList.remove('active');
});
<?php endif; ?>
</script>

</body>
</html>