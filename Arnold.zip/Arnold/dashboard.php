<?php
// ========================
// DASHBOARD.PHP
// ========================

require_once 'config.php';

// ========================
// AUTHENTICATION CHECK
// ========================
if (!isLoggedIn()) {
    redirect('login.php');
}

// Get user role and info
$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'user';

// Admin only check (remove if you want all roles to access)
if ($role !== 'admin') {
    die("Access denied. Admin only.");
}

// ========================
// FETCH DASHBOARD STATS
// ========================
try {
    // Total Players
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE role = 'player' AND status = 'active'");
    $stmt->execute();
    $total_players = $stmt->fetch()['total'] ?? 0;

    // Total Coaches
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE role = 'coach' AND status = 'active'");
    $stmt->execute();
    $total_coaches = $stmt->fetch()['total'] ?? 0;

    // Total Revenue (completed payments)
    $stmt = $conn->prepare("SELECT SUM(amount) as total FROM payments WHERE status = 'completed'");
    $stmt->execute();
    $revenue = $stmt->fetch()['total'] ?? 0;

    // Pending Payments
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM payments WHERE status = 'pending'");
    $stmt->execute();
    $pending_payments = $stmt->fetch()['total'] ?? 0;

    // Recent Payments (last 5)
    $stmt = $conn->prepare("
        SELECT p.*, u.full_name, u.email 
        FROM payments p 
        JOIN users u ON p.user_id = u.user_id 
        ORDER BY p.created_at DESC 
        LIMIT 5
    ");
    $stmt->execute();
    $recent_payments = $stmt->fetchAll();

    // Recent Users (last 5)
    $stmt = $conn->prepare("
        SELECT user_id, full_name, email, role, status, created_at 
        FROM users 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $stmt->execute();
    $recent_users = $stmt->fetchAll();

    // Upcoming Training Sessions
    $stmt = $conn->prepare("
        SELECT ts.*, u.full_name as coach_name 
        FROM training_sessions ts 
        JOIN users u ON ts.coach_id = u.user_id 
        WHERE ts.session_date >= CURDATE()
        ORDER BY ts.session_date ASC 
        LIMIT 5
    ");
    $stmt->execute();
    $upcoming_sessions = $stmt->fetchAll();

    // Monthly Revenue for Chart (last 6 months)
    $stmt = $conn->prepare("
        SELECT 
            DATE_FORMAT(created_at, '%b') as month,
            SUM(amount) as total
        FROM payments 
        WHERE status = 'completed' 
            AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY created_at ASC
    ");
    $stmt->execute();
    $monthly_revenue = $stmt->fetchAll();

    // Prepare chart data
    $chart_months = [];
    $chart_amounts = [];
    foreach ($monthly_revenue as $row) {
        $chart_months[] = $row['month'];
        $chart_amounts[] = (float)$row['total'];
    }

    // Fill missing months if less than 6
    if (count($chart_months) < 6) {
        $all_months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
        $existing_months = $chart_months;
        $existing_amounts = $chart_amounts;
        
        $chart_months = $all_months;
        $chart_amounts = [];
        foreach ($all_months as $month) {
            $index = array_search($month, $existing_months);
            if ($index !== false) {
                $chart_amounts[] = $existing_amounts[$index];
            } else {
                $chart_amounts[] = 0;
            }
        }
    }

    // Recent Notifications
    $stmt = $conn->prepare("
        SELECT * FROM notifications 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $stmt->execute();
    $recent_notifications = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log($e->getMessage());
    $error_message = "Failed to load dashboard data.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Dashboard | Sport Management System</title>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        /* Dashboard Container */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            padding: 30px 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-logo h2 {
            color: white;
            font-size: 1.5rem;
            margin-bottom: 5px;
        }

        .sidebar-logo p {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.85rem;
        }

        .nav-item {
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 10px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            text-decoration: none;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(5px);
        }

        .nav-item i {
            width: 24px;
            font-size: 1.2rem;
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            border-left: 3px solid white;
        }

        .logout-btn {
            margin-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            padding-top: 20px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
            overflow-x: hidden;
        }

        /* Header */
        .header {
            background: white;
            border-radius: 15px;
            padding: 20px 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .header h1 {
            color: #333;
            font-size: 1.5rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }

        .user-details {
            text-align: right;
        }

        .user-name {
            font-weight: bold;
            color: #333;
        }

        .user-role {
            font-size: 0.85rem;
            color: #666;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .stat-title {
            color: #666;
            font-size: 0.9rem;
            text-transform: uppercase;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }

        .stat-change {
            font-size: 0.85rem;
            color: #10b981;
        }

        /* Cards */
        .card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .card-header h3 {
            color: #333;
            font-size: 1.2rem;
        }

        .card-header i {
            color: #667eea;
            font-size: 1.2rem;
        }

        /* Tables */
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0f0f0;
        }

        th {
            color: #666;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
        }

        td {
            color: #333;
        }

        /* Status Badges */
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .badge-success {
            background: #d1fae5;
            color: #065f46;
        }

        .badge-warning {
            background: #fed7aa;
            color: #92400e;
        }

        .badge-info {
            background: #dbeafe;
            color: #1e40af;
        }

        .badge-active {
            background: #d1fae5;
            color: #065f46;
        }

        .badge-inactive {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Chart Container */
        .chart-container {
            position: relative;
            height: 300px;
            margin-top: 20px;
        }

        canvas {
            max-height: 300px;
            width: 100% !important;
        }

        /* Mobile Menu Button */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 56px;
            height: 56px;
            background: white;
            border-radius: 50%;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            border: none;
            cursor: pointer;
            z-index: 1001;
            color: #667eea;
            font-size: 1.5rem;
            transition: all 0.3s ease;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 10px;
            color: #ddd;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 20px;
            }

            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .overlay.active {
                display: block;
            }

            .stats-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .header {
                flex-direction: column;
                text-align: center;
            }

            .user-info {
                flex-direction: column;
                text-align: center;
            }

            .user-details {
                text-align: center;
            }

            th, td {
                padding: 8px;
                font-size: 0.85rem;
            }
        }

        /* Animations */
        @keyframes slideIn {
            from {
                transform: translateX(-100%);
            }
            to {
                transform: translateX(0);
            }
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
    </style>
</head>
<body>

<div class="dashboard-container">
    <!-- Mobile Menu Button -->
    <button class="mobile-menu-btn" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>
    <div class="overlay" id="overlay"></div>

      <div class="sidebar" id="sidebar">
        <div class="sidebar-logo"><h2><i class="fas fa-futbol"></i> SportMS</h2><p>Management System</p></div>
        <nav>
            <a href="dashboard.php" class="nav-item"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
            <a href="players.php" class="nav-item"><i class="fas fa-users"></i><span>Players</span></a>
            <a href="coaches.php" class="nav-item active"><i class="fas fa-chalkboard-user"></i><span>Coaches</span></a>
            
            <a href="sessions.php" class="nav-item"><i class="fas fa-calendar-alt"></i><span>Sessions</span></a>
           
            <div class="logout-btn"><a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></div>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header">
            <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
            <div class="user-info">
                <div class="user-details">
                    <div class="user-name"><?= e($full_name) ?></div>
                    <div class="user-role"><?= ucfirst(e($role)) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($full_name, 0, 1)) ?>
                </div>
            </div>
        </div>

        <?php if (isset($error_message)): ?>
            <div class="card" style="background: #fee2e2; color: #991b1b;">
                <i class="fas fa-exclamation-triangle"></i> <?= e($error_message) ?>
            </div>
        <?php endif; ?>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-title">Total Players</span>
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                </div>
                <div class="stat-value"><?= number_format($total_players) ?></div>
                <div class="stat-change"><i class="fas fa-user-plus"></i> Active members</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-title">Total Coaches</span>
                    <div class="stat-icon"><i class="fas fa-chalkboard-user"></i></div>
                </div>
                <div class="stat-value"><?= number_format($total_coaches) ?></div>
                <div class="stat-change"><i class="fas fa-chalkboard"></i> Available coaches</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-title">Total Revenue</span>
                    <div class="stat-icon"><i class="fas fa-dollar-sign"></i></div>
                </div>
                <div class="stat-value">KES <?= number_format($revenue) ?></div>
                <div class="stat-change"><i class="fas fa-arrow-up"></i> Lifetime earnings</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-title">Pending Payments</span>
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                </div>
                <div class="stat-value"><?= number_format($pending_payments) ?></div>
                <div class="stat-change"><i class="fas fa-exclamation-circle"></i> Awaiting action</div>
            </div>
        </div>

        <!-- Revenue Chart -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-chart-line"></i> Revenue Trend (Last 6 Months)</h3>
                <i class="fas fa-chart-simple"></i>
            </div>
            <div class="chart-container">
                <canvas id="revenueChart"></canvas>
            </div>
        </div>

        <!-- Recent Payments -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-credit-card"></i> Recent Payments</h3>
                <a href="payments.php" style="color: #667eea; text-decoration: none;">View All →</a>
            </div>
            <div class="table-responsive">
                <?php if (count($recent_payments) > 0): ?>
                    <table>
                        <thead>
                            <tr><th>User</th><th>Amount</th><th>Type</th><th>Status</th><th>Date</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_payments as $payment): ?>
                                <tr>
                                    <td><?= e($payment['full_name']) ?></td>
                                    <td>KES <?= number_format($payment['amount']) ?></td>
                                    <td><?= ucfirst(e($payment['payment_type'])) ?></td>
                                    <td>
                                        <span class="badge badge-<?= $payment['status'] == 'completed' ? 'success' : 'warning' ?>">
                                            <?= ucfirst(e($payment['status'])) ?>
                                        </span>
                                    </td>
                                    <td><?= date('M d, Y', strtotime($payment['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-credit-card"></i>
                        <p>No payments recorded yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px;">
            <!-- Recent Users -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-user-plus"></i> Recent Users</h3>
                    <a href="users.php" style="color: #667eea; text-decoration: none;">View All →</a>
                </div>
                <div class="table-responsive">
                    <?php if (count($recent_users) > 0): ?>
                        <table>
                            <thead>
                                <tr><th>Name</th><th>Role</th><th>Status</th><th>Joined</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_users as $user): ?>
                                    <tr>
                                        <td><?= e($user['full_name']) ?></td>
                                        <td><span class="badge badge-info"><?= ucfirst(e($user['role'])) ?></span></td>
                                        <td>
                                            <span class="badge badge-<?= $user['status'] == 'active' ? 'active' : 'inactive' ?>">
                                                <?= ucfirst(e($user['status'])) ?>
                                            </span>
                                        </td>
                                        <td><?= date('M d, Y', strtotime($user['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-users"></i>
                            <p>No users found</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Upcoming Training Sessions -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-calendar-alt"></i> Upcoming Sessions</h3>
                    <a href="sessions.php" style="color: #667eea; text-decoration: none;">View All →</a>
                </div>
                <div class="table-responsive">
                    <?php if (count($upcoming_sessions) > 0): ?>
                        <table>
                            <thead>
                                <tr><th>Session</th><th>Coach</th><th>Date</th><th>Time</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($upcoming_sessions as $session): ?>
                                    <tr>
                                        <td><?= e($session['title']) ?></td>
                                        <td><?= e($session['coach_name']) ?></td>
                                        <td><?= date('M d, Y', strtotime($session['session_date'])) ?></td>
                                        <td><?= date('h:i A', strtotime($session['session_time'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-calendar-alt"></i>
                            <p>No upcoming sessions</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recent Notifications -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-bell"></i> Recent Notifications</h3>
                <a href="notifications.php" style="color: #667eea; text-decoration: none;">View All →</a>
            </div>
            <div class="table-responsive">
                <?php if (count($recent_notifications) > 0): ?>
                    <table>
                        <thead>
                            <tr><th>Type</th><th>Recipient</th><th>Message</th><th>Date</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_notifications as $notification): ?>
                                <tr>
                                    <td><span class="badge badge-info"><?= strtoupper(e($notification['type'])) ?></span></td>
                                    <td><?= e($notification['recipient_phone']) ?></td>
                                    <td><?= substr(e($notification['message']), 0, 50) ?>...</td>
                                    <td><?= date('M d, Y h:i A', strtotime($notification['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-bell-slash"></i>
                        <p>No notifications yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
    // Revenue Chart
    const ctx = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($chart_months) ?>,
            datasets: [{
                label: 'Revenue (KES)',
                data: <?= json_encode($chart_amounts) ?>,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#667eea',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        boxWidth: 10
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'KES ' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'KES ' + value.toLocaleString();
                        }
                    },
                    grid: {
                        color: '#f0f0f0'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Mobile Menu Toggle
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    function closeMenu() {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }

    function openMenu() {
        sidebar.classList.add('active');
        overlay.classList.add('active');
    }

    if (menuToggle) {
        menuToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            if (sidebar.classList.contains('active')) {
                closeMenu();
            } else {
                openMenu();
            }
        });
    }

    if (overlay) {
        overlay.addEventListener('click', closeMenu);
    }

    // Close menu on nav item click (mobile)
    document.querySelectorAll('.nav-item').forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                closeMenu();
            }
        });
    });
</script>

</body>
</html>