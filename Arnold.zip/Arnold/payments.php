<?php
require_once 'config.php';

if (!isLoggedIn()) redirect('login.php');

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'user';

// Fetch user
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Fetch player details if role is player
$player = null;
if ($role === 'player') {
    $stmt = $conn->prepare("SELECT * FROM players WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $player = $stmt->fetch();
}

// Handle profile update
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    
    if (empty($full_name) || empty($phone)) {
        $error = "Name and phone are required.";
    } else {
        $stmt = $conn->prepare("UPDATE users SET full_name = ?, phone = ?, updated_at = NOW() WHERE user_id = ?");
        if ($stmt->execute([$full_name, $phone, $user_id])) {
            $_SESSION['full_name'] = $full_name;
            $message = "Profile updated successfully!";
            $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();
        } else {
            $error = "Failed to update profile.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
/* ===== GLOBAL ===== */
body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #667eea, #764ba2);
    margin: 0;
    padding: 20px;
}

/* ===== LAYOUT ===== */
.container {
    max-width: 900px;
    margin: auto;
}

/* ===== HEADER ===== */
.header {
    text-align: center;
    color: white;
    margin-bottom: 25px;
}

.avatar {
    width: 110px;
    height: 110px;
    border-radius: 50%;
    background: white;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: auto;
}

.avatar i {
    font-size: 50px;
    color: #667eea;
}

/* ===== CARD ===== */
.card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 20px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

.card h3 {
    margin-bottom: 15px;
    color: #333;
}

/* ===== GRID ===== */
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px,1fr));
    gap: 15px;
}

.item {
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
}

.label {
    font-size: 12px;
    color: gray;
}

.value {
    font-weight: bold;
}

/* ===== BUTTONS ===== */
.btn {
    padding: 10px 18px;
    border-radius: 10px;
    border: none;
    cursor: pointer;
    font-weight: bold;
}

.btn-primary {
    background: #667eea;
    color: white;
}

.btn-secondary {
    background: #eee;
}

.btn-danger {
    background: red;
    color: white;
}

/* ===== ALERT ===== */
.alert {
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 8px;
}

.success {
    background: #d1fae5;
    color: green;
}

.error {
    background: #fee2e2;
    color: red;
}

/* ===== FORM ===== */
input {
    width: 100%;
    padding: 10px;
    border-radius: 8px;
    border: 1px solid #ddd;
}

/* ===== TOGGLE ===== */
.hidden {
    display: none;
}
</style>

</head>
<body>

<div class="container">

    <!-- HEADER -->
    <div class="header">
        <div class="avatar">
            <i class="fas fa-user"></i>
        </div>
        <h2><?= htmlspecialchars($user['full_name']) ?></h2>
        <p><?= ucfirst($role) ?></p>
    </div>

    <!-- ALERT -->
    <?php if ($message): ?>
        <div class="alert success"><?= $message ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert error"><?= $error ?></div>
    <?php endif; ?>

    <!-- VIEW MODE -->
    <div id="view">

        <div class="card">
            <h3>Account Info</h3>

            <div class="grid">
                <div class="item">
                    <div class="label">Full Name</div>
                    <div class="value"><?= $user['full_name'] ?></div>
                </div>

                <div class="item">
                    <div class="label">Email</div>
                    <div class="value"><?= $user['email'] ?></div>
                </div>

                <div class="item">
                    <div class="label">Phone</div>
                    <div class="value"><?= $user['phone'] ?></div>
                </div>

                <div class="item">
                    <div class="label">Joined</div>
                    <div class="value"><?= $user['created_at'] ?></div>
                </div>
            </div>

            <br>

            <button class="btn btn-primary" onclick="toggle()">Edit</button>
        </div>

        <?php if ($role === 'player' && $player): ?>
        <div class="card">
            <h3>Player Info</h3>

            <div class="grid">
                <div class="item">
                    <div class="label">Position</div>
                    <div class="value"><?= $player['position'] ?></div>
                </div>

                <div class="item">
                    <div class="label">Jersey</div>
                    <div class="value"><?= $player['jersey_number'] ?></div>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>

    <!-- EDIT MODE -->
    <div id="edit" class="hidden">
        <div class="card">
            <h3>Edit Profile</h3>

            <form method="POST">
                <input type="text" name="full_name" value="<?= $user['full_name'] ?>" required><br><br>
                <input type="text" name="phone" value="<?= $user['phone'] ?>" required><br><br>

                <button class="btn btn-primary" name="update_profile">Save</button>
                <button type="button" class="btn btn-secondary" onclick="toggle()">Cancel</button>
            </form>
        </div>
    </div>

</div>

<script>
function toggle() {
    document.getElementById('view').classList.toggle('hidden');
    document.getElementById('edit').classList.toggle('hidden');
}
</script>

</body>
</html>