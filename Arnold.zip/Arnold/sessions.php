<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$full_name = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'user';

$message = '';
$error = '';

// Add Session
if (isset($_POST['add_session'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $coach_id = (int)$_POST['coach_id'];
    $session_date = $_POST['session_date'];
    $session_time = $_POST['session_time'];
    $location = trim($_POST['location']);
    $max_participants = (int)$_POST['max_participants'];
    
    $stmt = $conn->prepare("
        INSERT INTO training_sessions (title, description, coach_id, session_date, session_time, location, max_participants, created_at) 
        VALUES (:title, :description, :coach_id, :session_date, :session_time, :location, :max_participants, NOW())
    ");
    
    if ($stmt->execute([
        ':title' => $title, ':description' => $description, ':coach_id' => $coach_id,
        ':session_date' => $session_date, ':session_time' => $session_time,
        ':location' => $location, ':max_participants' => $max_participants
    ])) {
        $message = "Training session added successfully!";
    } else {
        $error = "Failed to add session.";
    }
}

// Delete Session
if (isset($_GET['delete'])) {
    $session_id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM training_sessions WHERE session_id = :session_id");
    if ($stmt->execute([':session_id' => $session_id])) {
        $message = "Session deleted successfully!";
    } else {
        $error = "Failed to delete session.";
    }
}

// Fetch Sessions
$sql = "SELECT ts.*, u.full_name as coach_name FROM training_sessions ts JOIN users u ON ts.coach_id = u.user_id ORDER BY session_date DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();
$sessions = $stmt->fetchAll();

// Fetch Coaches for dropdown
$stmt = $conn->prepare("SELECT user_id, full_name FROM users WHERE role = 'coach' AND status = 'active'");
$stmt->execute();
$coaches = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Training Sessions | SportMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .dashboard-container { display: flex; min-height: 100vh; }
        .sidebar { width: 280px; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-right: 1px solid rgba(255,255,255,0.2); padding: 30px 20px; position: fixed; height: 100vh; overflow-y: auto; transition: transform 0.3s ease; z-index: 1000; }
        .sidebar-logo { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.2); }
        .sidebar-logo h2 { color: white; font-size: 1.5rem; }
        .nav-item { padding: 12px 15px; margin: 5px 0; border-radius: 10px; display: flex; align-items: center; gap: 12px; color: white; text-decoration: none; transition: all 0.3s ease; }
        .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.2); transform: translateX(5px); }
        .nav-item i { width: 24px; }
        .logout-btn { margin-top: 30px; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 20px; }
        .main-content { flex: 1; margin-left: 280px; padding: 30px; overflow-x: hidden; }
        .header { background: white; border-radius: 15px; padding: 20px 25px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header h1 { color: #333; font-size: 1.5rem; }
        .user-avatar { width: 50px; height: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; }
        .card { background: white; border-radius: 15px; padding: 20px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px; }
        .card-header h2 { color: #333; font-size: 1.2rem; }
        .btn { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; transition: all 0.3s ease; }
        .btn-primary { background: #667eea; color: white; }
        .btn-danger { background: #ef4444; color: white; }
        .btn-sm { padding: 5px 12px; font-size: 0.8rem; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #f0f0f0; }
        th { color: #666; font-weight: 600; font-size: 0.85rem; }
        .badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; background: #dbeafe; color: #1e40af; }
        .modal { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 2000; align-items: center; justify-content: center; }
        .modal.active { display: flex; }
        .modal-content { background: white; border-radius: 15px; padding: 25px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; color: #666; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; }
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #d1fae5; color: #065f46; border-left: 4px solid #10b981; }
        .alert-error { background: #fee2e2; color: #991b1b; border-left: 4px solid #ef4444; }
        .mobile-menu-btn { display: none; position: fixed; bottom: 20px; right: 20px; width: 56px; height: 56px; background: white; border-radius: 50%; box-shadow: 0 2px 10px rgba(0,0,0,0.2); border: none; cursor: pointer; z-index: 1001; color: #667eea; font-size: 1.5rem; }
        .overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 999; }
        .empty-state { text-align: center; padding: 40px; color: #999; }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .mobile-menu-btn { display: flex; align-items: center; justify-content: center; }
            .overlay.active { display: block; }
            .card-header { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <button class="mobile-menu-btn" id="menuToggle"><i class="fas fa-bars"></i></button>
    <div class="overlay" id="overlay"></div>
    
   <div class="sidebar" id="sidebar">
        <div class="sidebar-logo"><h2><i class="fas fa-futbol"></i> SportMS</h2><p>Management System</p></div>
        <nav>
            <a href="dashboard.php" class="nav-item"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
            <a href="players.php" class="nav-item"><i class="fas fa-users"></i><span>Players</span></a>
            <a href="coaches.php" class="nav-item active"><i class="fas fa-chalkboard-user"></i><span>Coaches</span></a>
            
            <a href="sessions.php" class="nav-item"><i class="fas fa-calendar-alt"></i><span>Sessions</span></a>
           
            <div class="logout-btn"><a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></div>
        </nav>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1><i class="fas fa-calendar-alt"></i> Training Sessions</h1>
            <div class="user-avatar"><?= strtoupper(substr($full_name, 0, 1)) ?></div>
        </div>
        
        <?php if ($message): ?><div class="alert alert-success"><?= e($message) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
        
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-list"></i> All Sessions</h2>
                <button class="btn btn-primary" onclick="openAddModal()"><i class="fas fa-plus"></i> Add Session</button>
            </div>
            
            <div class="table-responsive">
                <?php if (count($sessions) > 0): ?>
                    <table>
                        <thead><tr><th>Title</th><th>Coach</th><th>Date</th><th>Time</th><th>Location</th><th>Max</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php foreach ($sessions as $session): ?>
                            <tr>
                                <td><?= e($session['title']) ?></td>
                                <td><?= e($session['coach_name']) ?></td>
                                <td><?= date('M d, Y', strtotime($session['session_date'])) ?></td>
                                <td><?= date('h:i A', strtotime($session['session_time'])) ?></td>
                                <td><?= e($session['location']) ?></td>
                                <td><?= $session['max_participants'] ?></td>
                                <td><a href="?delete=<?= $session['session_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this session?')"><i class="fas fa-trash"></i> Delete</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state"><i class="fas fa-calendar-alt" style="font-size: 3rem; color: #ddd;"></i><p>No training sessions found</p></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div id="addModal" class="modal"><div class="modal-content"><div style="display: flex; justify-content: space-between; margin-bottom: 20px;"><h3>Add Training Session</h3><button onclick="closeAddModal()" style="background: none; border: none; font-size: 1.5rem;">&times;</button></div>
<form method="POST"><div class="form-group"><label>Title *</label><input type="text" name="title" required></div><div class="form-group"><label>Description</label><textarea name="description" rows="3"></textarea></div><div class="form-group"><label>Coach *</label><select name="coach_id" required><?php foreach($coaches as $coach): ?><option value="<?= $coach['user_id'] ?>"><?= e($coach['full_name']) ?></option><?php endforeach; ?></select></div><div class="form-group"><label>Date *</label><input type="date" name="session_date" required></div><div class="form-group"><label>Time *</label><input type="time" name="session_time" required></div><div class="form-group"><label>Location *</label><input type="text" name="location" required></div><div class="form-group"><label>Max Participants</label><input type="number" name="max_participants" value="20"></div><button type="submit" name="add_session" class="btn btn-primary">Add Session</button></form></div></div>

<script>
function openAddModal() { document.getElementById('addModal').classList.add('active'); }
function closeAddModal() { document.getElementById('addModal').classList.remove('active'); }
window.onclick = function(event) { if (event.target.classList.contains('modal')) event.target.classList.remove('active'); }
const menuToggle = document.getElementById('menuToggle'), sidebar = document.getElementById('sidebar'), overlay = document.getElementById('overlay');
if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('active'); overlay.classList.toggle('active'); };
if(overlay) overlay.onclick = () => { sidebar.classList.remove('active'); overlay.classList.remove('active'); };
</script>
</body>
</html>